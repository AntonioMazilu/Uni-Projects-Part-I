package robotwars;

public class masterRoom extends Room
{
    String mstrRoom[];
    
    public masterRoom()
    {
        this.mstrRoom = new String[1];
    }

    public void master(Colony c1)
    {
        mstrRoom[0] = "[  \033[0;30m🤖\033[0m ]";
    }
}
