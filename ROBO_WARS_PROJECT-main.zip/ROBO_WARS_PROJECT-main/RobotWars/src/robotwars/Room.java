package robotwars;

public class Room extends Game
{   
    int[][] soldiers;
    
    Robot rob;  
    
    public Room()
    {
        
    }
    
    public Room(int x,int y)
    {
        this.soldiers = new int[x][y];
    }
    
    public void initializesol(Colony c2)//arxikopoiei ton pinaka ton stratioton
    {
        for (int i = 0;i <= c2.numTunnels() - 1;i++)
        {
            for (int j = 0;j <= c2.tunnelLength() - 1;j++)
            {
                soldiers[i][j] = 0;
            }
        }
    }
    
    public void initialize(Colony c1)//arxikopoiei ton pinaka
    {
        for (int i = 0;i < c1.numTunnels();i++)
        {
            for(int j = 0;j < c1.tunnelLength();j++)
            {
                c1.map[i][j] = "[     ]";
            }
        }   
    }
}