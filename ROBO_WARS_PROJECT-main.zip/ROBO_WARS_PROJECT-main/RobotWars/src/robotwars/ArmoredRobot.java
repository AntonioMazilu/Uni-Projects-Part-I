package robotwars;

public class ArmoredRobot extends Robot
{
    private int enrg;
    private static int stamina;
    
    public ArmoredRobot()
    {
        this.enrg = 3;
        this.stamina = 4;
    }
    public int reduce()
    {
        stamina--;
        return stamina;
    }
}
