package robotwars;

public class FireRobot extends Robot
{
    private int enrg;
    private static int stamina;
    
    public FireRobot()
    {
        this.enrg = 4;
        this.stamina = 1;
    }
    
    public int reduce()
    {
        stamina--;
        return stamina;
    }
}
