package robotwars;

public class Robot extends Actor
{
    private int energyNeeded;
    
    public int energytype(int type,int energy)//me bash to type toy robot bazei kai ti energy xreaizetai
    {
        if(type == 1)
        {
            energyNeeded = 3;
            
        }
        else if (type == 2)
        {
            energyNeeded = 3;
            
        }
        else if (type == 3)
        {
            energyNeeded = 4;
           
        }
        else if (type == 4)
        {
            energyNeeded = 4;
          
        }
        else if (type == 5)
        {
            energyNeeded = 4;
           
        }
        
        return energy - energyNeeded;
    }
}
