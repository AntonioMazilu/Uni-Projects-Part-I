package robotwars;

public class MasterRobot extends masterRoom
{
    private int stamina;
    
    public MasterRobot()
    {
        this.stamina = 1;
    }
}
