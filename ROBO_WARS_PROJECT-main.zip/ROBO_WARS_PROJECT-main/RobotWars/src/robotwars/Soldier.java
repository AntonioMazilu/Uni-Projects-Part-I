package robotwars;

public class Soldier extends Actor
{
    private int stamina = 3;
    private static int DAMAGE = 1;
    private int sum = 0;
    private int type;
    
    public int  attack()//epitiuetai o stratioths sto robot
    {
        return DAMAGE;
    }
    
    public int moveTo(Room r1,int i,int j,Colony c1,masterRoom mr)//metakinei ton stratioth sto epomeno domatio
    {   
        if (j == 0)
        {
            mr.mstrRoom[0] = "[  💂  ]"; 
            return 1;
        }
        
        c1.map[i][j] = "[  💂  ]";  
        j++;
        
        if(j > c1.tunnelLength()-1)
        {
            System.out.println("");
        }
        else
        {
            c1.map[i][j] = "[     ]";
        }
        
        return 0;
    }
    
   public int solarr(Colony c2,Room r1)//an o pinakas ton stratioton einai adeios apo statiotes tote kerdizei o paixths
   {
        for (int i = 0;i < c2.numTunnels() - 1;i++)
        {
            for (int j = 0;j < c2.tunnelLength() - 1;j++)
            {
                if(r1.soldiers[i][j] == 0)
                {
                    sum++;
                }
            }
        }
        
        if (sum == ((c2.numTunnels() - 1) + (c2.tunnelLength() - 1)))
        {
            return 3;
        }
        return 0;
   }
}