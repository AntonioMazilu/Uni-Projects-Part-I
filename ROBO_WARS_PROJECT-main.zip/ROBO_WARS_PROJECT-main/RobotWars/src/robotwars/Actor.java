package robotwars;

public class Actor extends Room
{
    private int amount;
    private int stamina;
    private int flag;
    
    public Actor()
    {
        this.stamina = stamina;
        this.amount =  amount;
    }            
    
    public int reduceStamina(int amount,Robot rb1)
    {
        
        return 0;
    }
    
    public int act(int i,int j,Colony c1,Robot rb1,int amount)//ensomatomeno to leaveRoom kai thn reduceStamina
    {
        int type = 0;
        
        if(c1.map[i][j].equals("\033[0;37m🤖\033[0m"))
        {
            type = 1;
            EnergyProducerRobot enrRb = new EnergyProducerRobot();
            flag = enrRb.reduce();
            
            if (flag == 1)
            {
      
                return 1;
            }
        }
        else if (c1.map[i][j].equals("\033[0;31m🤖\033[0m"))
        {
            type = 2;
            ArmoredRobot ArmRB = new ArmoredRobot();
            flag = ArmRB.reduce();
            
            if (flag == 1)
            {
               
                return 1;
            }
        }
        else if (c1.map[i][j].equals("\033[0;33m🤖\033[0m"))
        {
            type = 3;
            FighterRobot FighRB = new FighterRobot();
            flag = FighRB.reduce();
            
            if (flag == 1)
            {
                
                return 1;
            }
        }
        else if (c1.map[i][j].equals("\033[0;34m🤖\033[0m"))
        {
            type = 4;
            ShooterRobot ShRB = new ShooterRobot();
            flag = ShRB.reduce();
            
            if (flag == 1)
            {
                
                return 1;
            }
        }
        else if (c1.map[i][j].equals("\033[0;35m🤖\033[0m"))
        {
            type = 5;
            FireRobot FrRB = new FireRobot();
            flag = FrRB.reduce();
            
            if (flag == 1)
            {
              
                return 1;
            }
        }
        
        return 0;
    }
}
