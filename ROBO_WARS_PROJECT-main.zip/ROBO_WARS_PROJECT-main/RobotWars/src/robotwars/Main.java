package robotwars;

public class Main 
{
    public static void main(String[] args)
    {
        Game RBW = new Game();
        RBW.create();
        RBW.play();
    }
}