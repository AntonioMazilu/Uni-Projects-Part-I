package robotwars;

public class ShooterRobot extends Robot
{
    private int energyNeeded;
    private static int stamina;
    
    public ShooterRobot()
    {
        this.energyNeeded = 4;
        this.stamina = 1;
    }
    
    public int reduce()
    {
        stamina--;
        return stamina;
    }
}
