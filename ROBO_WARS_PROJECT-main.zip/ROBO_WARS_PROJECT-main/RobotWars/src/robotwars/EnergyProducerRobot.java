package robotwars;

public class EnergyProducerRobot extends Robot
{
    private int enrg;
    static int stamina;
    
    public EnergyProducerRobot()
    {
        this.enrg = 3;
        this.stamina = 1;
    }
    
    public int reduce()
    {
        stamina--;
        return stamina;
    }
}
