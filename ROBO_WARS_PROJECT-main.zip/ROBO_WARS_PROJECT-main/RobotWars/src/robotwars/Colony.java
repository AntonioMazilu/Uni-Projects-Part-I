package robotwars;

public class Colony extends Game
{
    private static int energy;
    private int tunnels;
    private int lengthtunnel;
    
    String map[][];
    
    public Colony(int tunnels,int lengthtunnel,int energy)
    {
       this.tunnels = tunnels;
       this.lengthtunnel = lengthtunnel;
       this.map = new String[tunnels][lengthtunnel];
       this.energy = energy;  
    }
    
    public int getEnergy()
    {
        return energy;
    }
    
    public int numTunnels()
    {
        return tunnels;
    }
    
    public int tunnelLength()
    {
        return lengthtunnel;
    }
    
    public void putsoldiers(int sum,Room r1)//bazei tous stratiotes ston pinaka se tyxaeis ueseis
    {
        int sum1;
        int x = numTunnels() - 1;
        
        while(sum > 0 || x >= 0)
        {
            sum1 = 0;
            
            if (sum == 1)
            {
                r1.soldiers[x][tunnelLength() - 1] = sum;
                sum = 0;
            }
            
            if(sum % 2 == 0)
            {
                sum1=sum/2;
                if(sum1 == 1)
                {
                    r1.soldiers[x][tunnelLength() - 1] = sum1;
                    sum = sum - sum1;
                    x--;
                }
                else
                {
                    r1.soldiers[x][tunnelLength() - 1] = sum1;
                    sum = sum - sum1;
                    x--;
                }
            }
            else if(sum % 2 == 1)
            {
                sum1=sum/2;
                if(sum == 1)
                {
                    if(x < 0)
                    {
                        break;
                    }
                    r1.soldiers[x][tunnelLength() - 1] = sum1;
                    sum = sum - sum1;
                    if(sum % 2 == 0)
                    {
                        r1.soldiers[x][tunnelLength() - 1] = sum1 + sum;
                        sum = 0;
                    }
                    x--;
                }
                else
                {
                   r1.soldiers[x][tunnelLength() - 1] = sum1;
                    sum = sum - sum1;
                    x--; 
                }
            }
        }
    }
    
    public void putrobots(int type,int energy,int x,int y)
    {
        if (energy > 0)
        {
            if (type == 1)
            {
                map[x][y] = "[  \033[0;37m🤖\033[0m  ]";//bazei robot
            }
            else if (type == 2)
            {
                map[x][y] = "[  \033[0;31m🤖\033[0m  ]";//bazei robot
            }
            else if(type == 3)
            {
                map[x][y] = "[  \033[0;33m🤖\033[0m  ]";//bazei robot
            }
            else if(type == 4)
            {
                map[x][y] = "[  \033[0;34m🤖\033[0m  ]";//bazei robot
            }
            else if(type == 5)
            {
                map[x][y] = "[  \033[0;35m🤖\033[0m  ]";//bazei robot
            }
        }
        else
        {
            System.out.println("No more energy");
        }
    }
    
    public void printarr(masterRoom mr)//ektyponei ton pinaka
    {
        for (int i = 0;i < numTunnels();i++)
        {   
                
            for(int j = 0;j < tunnelLength();j++)
            {
                System.out.print("" + map[i][j]);
            }
            System.out.println("");
        }
    }
}
