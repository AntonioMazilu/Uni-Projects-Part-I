package robotwars;
        
import java.util.InputMismatchException;
import java.util.Scanner;

import java.util.Random;

public class Game 
{
    private int answer;
    private int answer2;
    
    private int sumtun; 
    private int sumroom;
    private int energy;
    
    private int robot = 0;
    private int x;
    private int y;
    
    private int maxsoldiers;
    private int sumsold;
    
    private int flag1 = 0;
    private int flag2 = 0;
    private int flag3 = 0;
    private int flag4 = 0;
    
    private int amount = 0;
    private int type;
    
    
    private Soldier s1;
    private Robot rb1;
    private Actor ac;
    private masterRoom mr; 
    private Colony c1;
    private Room r1;
    
    
    Scanner input = new Scanner(System.in);
    Random rnd = new Random();
    
    
    public void create()//pairnei ta dedomena apo to xrhsth kai dhmhougei to paixnidi gia na paijei o xhrshts
    {
        System.out.println("Welcome to Robot Wars");
        
        while(answer != 3)
        {
            answer = menu();
       
            if (answer == 1)
            {
                answer2 = choosemode();//dialegei to mode pou uelei na paijei
                
                System.out.println("Give the colonies you want to play");//parnei poses syragges einai
                sumtun = input.nextInt();
                
                while (sumtun < 0)
                {
                    System.out.println("Wrong.Must be positive number");
                    System.out.println("Give the colonies you want to play");//parnei poses syragges einai
                    sumtun = input.nextInt();
                }
                
                System.out.println("Give the rooms for each colony");//pairnei posa domatia einai
                sumroom = input.nextInt();
                
                while (sumroom < 0)
                {
                    System.out.println("Wrong.Must be positive number");
                    System.out.println("Give the rooms you want to play");//parnei posa domatia einai
                    sumroom = input.nextInt();
                }
                
                System.out.println("Give the total amount of energy");//pairnei thn stamina gia olo to paixnidi
                energy = input.nextInt();
                
                while (energy < 0)
                {
                    System.out.println("Wrong.Must be positive number");
                    System.out.println("Give the total amount of energy");//pairnei thn stamina gia olo to paixnidi
                    energy = input.nextInt();
                }
                
                c1 = new Colony(sumtun,sumroom,energy);//ftiaxnei ta domatia me tis syragges
                r1 = new Room(sumtun,sumroom);
                mr = new  masterRoom();
                r1.initialize(c1);//arxikopoiei ton pinaka
                break;
            }
            else 
            {
                System.exit(0);
            } 
        }
    }

    public int menu()//menu
    {
        System.out.println("Choose a option:");
        System.out.println("1.Play");
        System.out.println("3.Exit");
        System.out.print("Answer:");
        answer = input.nextInt();
        
        while (answer != 1 && answer != 2 && answer != 3)
        {
            System.out.println("Wrong.Choose again");
            System.out.println("Choose a option:");
            System.out.println("1.Play");
            System.out.println("3.Exit");
            System.out.print("Answer:");
            answer = input.nextInt();
        }
        
        return answer;
    }
    
    public int choosemode()//menu
    {
        System.out.println("Choose mode");
        System.out.println("1.Easy");
        System.out.println("2.Medium");
        System.out.println("3.Hard");
        System.out.print("Answer:");
        answer2 = input.nextInt();
        
        while (answer2 != 1 && answer2 != 2 && answer2 != 3)
        {
            System.out.println("Wrong.Choose again");
            System.out.println("Choose mode");
            System.out.println("1.Easy");
            System.out.println("2.Medium");
            System.out.println("3.Hard");
            System.out.print("Answer:");
            answer2 = input.nextInt();
        }
        
        return answer2;
    }
  
    public void FAQ()
    {
        System.out.println("OXI AKOMA");
    }
    
    public int insertrobot()//tou leei ta robot pou mporei na epilejei
    {
        
        
           System.out.println("Insert your robot");
            System.out.println("1.EnergyProducerRobot \033[0;37m🤖\033[0m Stamina:1 Energy required:3");
            System.out.println("2.ArmoredRobot \033[0;31m🤖\033[0m Stamina:4 Energy required:3");
            System.out.println("3.FighterRobot \033[0;33m🤖\033[0m Stamina:1 Energy required:4");
            System.out.println("4.ShooterRobot \033[0;34m🤖\033[0m Stamina:1 Energy required:4");
            System.out.println("5.FireRobot \033[0;35m🤖\033[0m Stamina:1 Energy required:4");
            System.out.println("6.Start");
            System.out.print("Answer:");
            robot = input.nextInt();
        
        
        while(robot != 1 && robot != 2 && robot != 3 && robot != 4 && robot != 5 && robot != 6)
        {
            System.out.println("Wrong");
            System.out.println("Choose again:");
            System.out.println("1.EnergyProducerRobot \033[0;37m🤖\033[0m");
            System.out.println("2.ArmoredRobot \033[0;31m🤖\033[0m");
            System.out.println("3.FighterRobot \033[0;33m🤖\033[0m");
            System.out.println("4.ShooterRobot \033[0;34m🤖\033[0m");
            System.out.println("5.FireRobot \033[0;35m🤖\033[0m");
            System.out.println("6.Start");
            System.out.print("Answer:");
            robot = input.nextInt();
        }
        
        return robot;
    }
    
    public int randomsoldiers(int answer)//dialegei to plhuos ton soldiers me bash to difficulty kai dialegei tyxaio plhuos **extra
    {
        
        if (answer == 1)
        {
            maxsoldiers = c1.numTunnels();
            sumsold = rnd.nextInt(maxsoldiers) + 1;  
            return sumsold;
        }
        else if (answer == 2)
        {
            maxsoldiers = 2 * c1.numTunnels();
            sumsold = rnd.nextInt(maxsoldiers) + 1;  
            return sumsold;
        }
        else
        {
            maxsoldiers = 4 * c1.numTunnels();
            sumsold = rnd.nextInt(maxsoldiers) + 1;  
            return sumsold;
        }
    }
    
    public void play()
    {
        while(flag4 == 0)
        {
            r1 = new Room(sumtun,sumroom);
            s1 = new Soldier();
            rb1 = new Robot();
            ac = new Actor();
            
            c1.printarr(mr);//emfanizei ton pinaka
            sumsold = randomsoldiers(answer2);//pairnei to synolo ton strativtvn
            r1.initializesol(c1);//arxikopoiei ton pinaka ton stratioton
            c1.putsoldiers(sumsold,r1);//bazei tous stratiotes se tyxaies ueseis
            System.out.println("soldiers" + sumsold);
       
            while (robot != 6)
            {
                if(energy > 0)
                {
                    robot = insertrobot();
                    
                    if (robot == 6)
                    {
                        break;
                    }
                   
                    System.out.print("X pos:");
                    x = input.nextInt();
                    
                    while (x < 0 || x > c1.numTunnels())
                    {
                        System.out.println("Wrong");
                        System.out.println("Choose again:");
                        System.out.print("X pos:");
                        x = input.nextInt();
                    }
                    
                    System.out.print("Y pos:");
                    y = input.nextInt();
                    
                    while (y < 0 || y > c1.tunnelLength())
                    {
                        System.out.println("Wrong");
                        System.out.println("Choose again:");
                        System.out.print("Y pos:");
                        y = input.nextInt();
                    }
                    
                    c1.putrobots(robot,energy,x,y);//bazei ta robots sto domatio pou uelei
                    energy = rb1.energytype(robot,energy);//meionei to  energy
                    
                    System.out.println("Energy:" + energy);
                    
                    if (energy < 0)//check
                    {
                        System.out.println("Your energy is low.");
                        System.out.println("You can't place other robots"); 
                    }
                    
                    c1.printarr(mr);//emfanizei ton pinaka
                }
                else
                {
                    robot = 6;
                }
            }
            
            flag1 = 0;
            
            while(flag1 < 500)
            {
                
                try//apla perimenei
                {
                    Thread.sleep(2000);
                }
                catch(InterruptedException ex)
                {
                    Thread.currentThread().interrupt();
                }
                
                for (int i = c1.numTunnels()-1;i >= 0;i--)
                {
                    for (int j = c1.tunnelLength()-1;j >= 0;j--)
                    {     
                        System.out.println("Energy: "+ energy + "" + " Soldiers: " + sumsold);//emfanizetai kaue fora pou paizei o paixths
                        
                        try//apla perimenei
                        {
                            Thread.sleep(2000);
                        }
                        catch(InterruptedException ex)
                        {
                            Thread.currentThread().interrupt();
                        }
                        
                        if (c1.map[i][j].equals("[     ]"))
                        {
                            flag2 = s1.moveTo(r1,i,j,c1,mr);
                            
                            if (flag2 == 1)
                            {
                                System.out.println("Game Over!!");
                                flag1= 1000;
                                flag4 = 1;
                                i=-1;
                                j=-1;
                                break;
                            }
                        }
                        else
                        {
                            amount = s1.attack();
                            
                            flag3 = ac.act(i,j,c1,rb1,amount);//kanei kapoies leitourgies
                            if (flag3 == 1)
                            {
                                c1.map[i][j] = "[  💂  ]";
                            }
                            else
                            {
                                r1.soldiers[i][j] = 0;
                            }
                        }
                        c1.printarr(mr);//emfanizei ton pinaka
                        System.out.println("");  
                    }
                }
                
                if (s1.solarr(c1,r1) == 3)//an o pinakas ton stratioton einai adeios apo statiotes tote kerdizei o paixths
                {
                    System.out.println("Congratulations.You win");
                    System.exit(0);
                    flag1 = 1000;
                    flag4 = 1;
                    break;
                }   
            }
            r1.initialize(c1);;//arxikopoiei ton pinaka
        }
    }
}