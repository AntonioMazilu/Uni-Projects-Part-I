#include <stdio.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#define SA struct sockaddr
   
int main(int argc,char *argv[])
{
    int sockfd,clilen,x;
    char server_message[200],client_message[200];
    struct sockaddr_in servaddr,cli_addr;
    FILE *file2;
    int i;
    
    //ftiaxnetai to socket kai ginetai kai elegxos gia to ama dhmhourghuhke h oxi
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) 
    {
        printf("Unsuccesful socket creation\n");
        exit(0);
    }
    else
        printf("Succesful socket creation\n");
        
        x=atoi(argv[1]);
   
    //edo dinoume thn ip tou server kai to port tou antistoixa
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(x);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
   
    // ginetai bind to socket kai elegxetai h ip
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0)//epistrefei mia timh gia to ama egine to bind h oxi
    {
        printf("Unsuccesful socket binding\n");
        exit(0);
    }
    else
    {
      printf("Succesful socket binding\n");
    }
   
    //to server einai etoimo na akousei
    printf("Server is listening...\n");
    listen(sockfd,1);

    int new_sockfd;                   /* new socket id */
    
   
    //apodexetai ta dedomena tou client kai ta elegxei kiolas
    clilen = sizeof(cli_addr);//to megeuos tou mhnymatos
    new_sockfd = accept(sockfd,(struct sockaddr *) &cli_addr,&clilen);
    
    //elegxei ama o server apantaei h oxi sto client
    if (new_sockfd < 0) 
    {
        printf("Server didnt renspond\n");
        exit(0);
    }
    else
    {
        printf("Server rensponded\n");
    }
        
        //mhnyma se ti ip kai port syndeuhke o client
        printf("Client connected at IP: %s and port: %i\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
        
    //edo anoigei to arxeio recv.txt kai elegxei an mporei na to diabasei h oxi
    if(!(file2 = fopen("recv.txt", "w+")))
    {
      printf("Error opening the file\n");
      return (-1);
    }
         
    //edo kanei receive o server apo ton client ta dedomena kai ta grafei sto arxeio reccv.txt allios den ta grafei       
    if (recv(new_sockfd, client_message, sizeof(client_message), 0) < 0)
    {
        printf("Couldn't receive\n");
        return -1;
    }
    else
    {
         //grafei ta dedomena
         for (i = 0; client_message[i]!='\0'; i++) 
         {
           fputc(client_message[i],file2);
         }
        
    }  
    
    //kleinoume to arxeio sto opoio metaferame ta dedomena
    fclose(file2); 
    
    printf("Succesful data transport from the client\n");
     
    strcpy(server_message, "Succesful data transport\n");
    
    //stelnei ena mhnyma sto client oti ta dedomena staluhkan epityxos allios den stelnei
    if (send(new_sockfd, server_message, strlen(server_message), 0) < 0)
    {
        printf("Can't send\n");
        return -1;
    }
   
    //afou teleiosei thn metafora toy arxeiou kai o server to antigracei sto diko tou arxeio kleinoume thn syndesh
    close(new_sockfd);
    close(sockfd);
    
    return 0;
}