#include <stdio.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#define SA struct sockaddr

int main(int argc,char *argv[])
{
    int sockfd,x;
    struct sockaddr_in servaddr;
    char server_msg[200];
    FILE *file1;
    char line[100];
    
    //ftiaxnetai to socket kai ginetai kai elegxos gia to ama dhmhourghuhke h oxi
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) 
    {
        printf("Unsuccesful socket creation\n");
        exit(0);
    }
    else
        printf("Succesful socket creation\n"); 
        
        
        //metatrepei to 40131 pou einai se alfariumhtiko se akeraio
        x=atoi(argv[2]);
        
    // dinoume thn ip kai to port antistoixa
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(x);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
   
    //edo syndeoume ton client me to server kai kanoume elegxo ama einai epityxhs h syndesh h oxi
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) 
    {
        printf("Unsuccesful connection[client->server]\n");
        exit(0);
    }
    else
    {
        printf("Succesful connection[client->server]\n");
    }
    
    //edo anoigei to arxeio send.txt kai elegxei an mporei na to diabasei h oxi
    if(!(file1 = fopen("send.txt", "r")))
    {
      printf("Error opening the file\n");
      return (-1);
    }
    
    
    //edo pairnoume ta dedomena etoima apo to arxeio send.txt kai sth synexeia ta stelnoume sto server
    while (!feof(file1))
    {
      if( fgets (line, 100, file1)!=NULL) 
      {
        
        if(send(sockfd,line,strlen(line),0) < 0)
        {
            printf("Unsuccesful send\n");
            return -1;
        }
        
      }
    }
    
    //kleinoume to arxeio afou staluhkan ola ta dedomena
    fclose(file1);
    
    //edo se periptosi pou ta dedomena den staluhkan enhmeronei to client
    if(recv(sockfd, server_msg, sizeof(server_msg), 0) < 0)
    {
        printf("Error:Server took to long to renspond\n");
        return -1;
    }
    
    printf("SERVER RENSPONSED: %s",server_msg);
   
    //kai telos kleinoume to socket
    close(sockfd);
}
