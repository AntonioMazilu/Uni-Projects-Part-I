// ----- 1o Project - domes dedomenwn -----
// ------------------------------------------------------------------
// Sxoinoplokakhs Emmanouhl  (dit20204@go.uop.gr) - (2022202000204) |
// Ion Antonio Mazilou       (dit20131@go.uop.gr) - (2022202000131) |
// ------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
} list;

struct Node *insertotlist(struct Node *head,int result);
int calculate(int a,int b,int select);

int main()
{
    int n, i, select = 0,a, b;
    int result;

    printf("Welcome to Galois Fields calculator\n");

    printf("Give the size n of the Galoi field: ");
    scanf("%d",&n);

    while (n > 10 || n < 2)
    {
        printf("The size should be between [2-10]");
        scanf("%d",&n);
        // printf("\n");
    }

    list **ptr;
    ptr = (list **) malloc(n * sizeof(list *));
    for (i = 0; i < n; i++)
    {
        ptr[i] = (list *) malloc(n * sizeof(list)); 
    }

    printf("\n");

    do 
    {
        printf("1. Exit\n");
        printf("2. Multiply\n");
        printf("3. Addition\n");
        printf("Select: ");
        scanf("%d", &select);

        printf("\n");
        
        switch (select)
        {
            case 1:

            break;
            case 2: 
                printf("Give a and b elements:");
                scanf("%d %d",&a,&b);
                result = calculate(a,b,select);
                printf("%d\n", result);
                //insertotlist(result);
            break;
            case 3:
                printf("Give a and b elements:");
                scanf("%d %d",&a,&b);
                result = calculate(a,b,select);
                printf("Addition of a and b is %d\n",result);
                //insertotlist(result);
            break;
        }

    } while(select != 1);

    for (i = 0; i < n; i++) {
        free(ptr[i]);
    }
    free(ptr);

    return 0;
}

list *insertotlist(struct Node *head,int result)
{   
    list *newItem, *temp;

    newItem = (list *) malloc(sizeof(list));

    if (newItem == NULL)
    {
        // den exei mnhmh diathesimh
        printf("Error! No memory available.\n");
        exit(1);
    } 
    else 
    {
        // temp->data = temp;
        newItem->next = NULL;

        if (head == NULL)
        {
            head = newItem;
        }
        else 
        {
         	newItem->next = head;
         	head = newItem;
   		}
   	}
      
    return head;
}

int calculate(int a,int b,int select)
{
    if (select == 3) {
        return a ^ b;
    }
}