//ΠΑΥΛΟΣ ΣΥΓΡΙΜΗΣ AM:2022202000202
//ΙΟΝ ΑΝΤΟΝΙΟ ΜΑΖΙΛΟΥ AM:2022202000131


#include <stdio.h>
#include <stdlib.h> 

int main (void)
{
    int x[6][7] = {{1,1,1,1,1,1,1},{3,0,1,0,0,0,1},{1,0,1,0,1,0,0},{1,0,0,0,1,1,1},{1,0,1,0,0,0,1},{1,1,1,1,1,1,1}};
    char k[6][7];
    int stack[30][2];
    int i,j;
    int m = 1,n = 0, top = -1;
    int m1,n1;
    int flag0 = 0;

    FILE *fpfile;
    
    fpfile = fopen("labyrinth.txt","w+");

    if(fpfile == NULL)
    {
        printf("File name could not be opened\n");
        exit(1);
    }
    
    printf("\n");

    for(i = 0; i < 6; i++)//gia na printarei ton pinaka jana me tis allages
    {
        for(j = 0;j < 7;j++)
        {
            if(x[i][j] == 1)
            {
                k[i][j] = '#';
                fputc(k[i][j], fpfile);
                fputc(' ',fpfile);
            }
            else if(x[i][j] == 0)
            {
                k[i][j] = ' ';
                fputc(k[i][j], fpfile);
                fputc(' ',fpfile);
            }
            else if(x[i][j] == 3)
            {
                k[i][j] = '*';
                fputc(k[i][j], fpfile);
                fputc(' ',fpfile);
            }
        }   
        fputc('\n',fpfile);
    }
    
    //debugging
    for(i = 0; i < 6; i++)
    {
        for(j = 0;j < 7;j++)
        {
            printf("%c ",k[i][j]);
        }
        printf("\n");
    }

    fputc('\n',fpfile);

        while((flag0 != 1) && ((m != 2) || (n != 6)) )//koitaei tous geitones kai elegxei kiolas
        {

            printf("%d %d\n",m,n);
            if(x[m + 1][n] != 3)//kato geitona
            {
                if(x[m + 1][n] != 1)
                {
                    if(top == 29 )
                    {
                        printf("Stack is overflowed. Can't add more data!\n");
                        flag0 = 1;
                    }
                    else
                    {
                        //printf("okkato\n");
                        top++;
                        stack[top][0] = m + 1;
                        stack[top][1] = n; 
                        m1 = stack[top][0];
                        //printf("m1 = %d\n",m1);
                        n1 = stack[top][1];
                        //printf("n1 = %d\n",n1);
                    }
                }
            }

            if(x[m - 1][n] != 3)//pano geitona
            {
                if(x[m - 1][n] != 1)//ama einai toixos
                {
                    if(top == 29 )
                    {
                        printf("Stack is overflowed. Can't add more data!\n");
                        flag0 = 1;
                    }
                    else
                    {
                        //printf("okpano\n");
                        top++;
                        stack[top][0] = m - 1;
                        stack[top][1] = n; 
                        m1 = stack[top][0];
                        //printf("m1 = %d\n",m1);
                        n1 = stack[top][1];
                        //printf("n1 = %d\n",n1);
                    }
                    
                }
            }

            if(x[m][n + 1] != 3)//degia geitona
            {
                if(x[m][n + 1] != 1)
                {
                    if(top == 29 )
                    {
                        printf("Stack is overflowed. Can't add more data!\n");
                        flag0 = 1;
                    }
                    else
                    {
                        //printf("okdejia\n");
                        top++;
                        stack[top][0] = m;
                        stack[top][1] = n + 1;
                        m1 = stack[top][0];
                        //printf("m1 = %d\n",m1);
                        n1 = stack[top][1];
                        //printf("n1 = %d\n",n1);
                    }
                }
            }

            if(x[m][n - 1] != 3 )//aristera geitona
            {
                if(x[m][n - 1] != 1)
                {
                    if(x[m][n - 1] != 0)
                    {
                        if(top == 29 )
                        {
                            printf("Stack is overflowed. Can't add more data!\n");
                            flag0 = 1;
                        }
                        else
                        {
                            //printf("okaristera\n");
                            top++;
                            stack[top][0] = m;
                            stack[top][1] = n - 1; 
                            m1 = stack[top][0];
                            //printf("m1 = %d\n",m1);
                            n1 = stack[top][1];
                            //printf("n1 = %d\n",n1);
                        }
                    }
                }
            }
            
            printf("-------------------\n");
            printf("top = %d\n",top);//gia thn metafora mesa sto labyrinth
            m = m1;//gia thn metafora mesa sto labyrinth
            //printf("m = %d\n",m);//gia thn metafora mesa sto labyrinth
            n = n1;//gia thn metafora mesa sto labyrinth
            //printf("n = %d\n",n);//gia thn metafora mesa sto labyrinth
            x[m][n] = 3;//gia thn metafora mesa sto labyrinth
            printf("telos episkeceis\n");
            
            for(i=0;i < top;i++)//printarei to stack
            {
                printf("|%d %d|",stack[i][0],stack[i][1]);
                printf("\n");
                printf("-----");
                printf("\n");
            }
    
            printf("\n");    

            for(i = 0; i < 6; i++)//gia na printarei ton pinaka jana me tis allages
            {
                for(j = 0;j < 7;j++)
                {
                    if(x[i][j] == 1)
                    { 
                        fputc(k[i][j], fpfile);
                        fputc(' ',fpfile);
                    }
                    else if(x[i][j] == 0)
                    {
                        fputc(k[i][j], fpfile);
                        fputc(' ',fpfile);
                    }
                    else if(x[i][j] == 3)
                    {
                        k[i][j] = '*';
                        fputc(k[i][j], fpfile);
                        fputc(' ',fpfile);
                    }
                }   
                fputc('\n',fpfile);
            }
            fputc('\n',fpfile);
        }

        //debugging
        for(i = 0; i < 6; i++)
        {
            for(j = 0;j < 7;j++)
            {
                printf("%c ",k[i][j]);
            }
            printf("\n");
        }
        
        for(i = 30;i > 0;i--)//adeiajei thn stoiba
        {
          stack[top][0] = 0;
          stack[top][1] = 0;
          top--;
          
          if(top == -1)
          {
            break;
          } 
        }
        
        for(i=0;i < top;i++)//printarei to stack
        {
            printf("|%d %d|",stack[i][0],stack[i][1]);
            printf("\n");
            printf("-----");
            printf("\n");
        }

        printf("TELOS!!!\n");
        fclose(fpfile);
        
        return 0;
}