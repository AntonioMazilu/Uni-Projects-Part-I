﻿using System;
using System.Collections.Generic;
using System.Linq;

public record Accusation(CrimeType TypeOfCrime, CrimeSeverity Severity, string Description, DateTime DateOccurred);

public enum CrimeType { Theft, Assault, Fraud, Homicide }
public enum CrimeSeverity { Low, Medium, High, LifeThreatening }

public class CriminalRecord
{
    public string Name { get; }
    public string Nickname { get; }
    public DateTime BirthDate { get; }
    public Accusation AccusationDetails { get; }
    public CriminalGroup GroupAffiliation { get; }

    public CriminalRecord(string name, string nickname, DateTime birthDate, Accusation accusationDetails, CriminalGroup groupAffiliation)
    {
        Name = name;
        Nickname = nickname;
        BirthDate = birthDate;
        AccusationDetails = accusationDetails;
        GroupAffiliation = groupAffiliation;
    }
}

public class CriminalGroup
{
    public string GroupName { get; }
    public List<CriminalRecord> Members { get; }

    public CriminalGroup(string groupName, List<CriminalRecord> members)
    {
        GroupName = groupName;
        Members = members;
    }
}

public interface ICriminalRecords
{
    IReadOnlyList<CriminalRecord> CriminalRecords { get; }
}

public interface ICriminalIterator : IEnumerable<CriminalRecord>
{
    // Den to xreiazomai
}

public interface IPoliceCriminalDatabase : ICriminalRecords
{
    List<CriminalGroup> CriminalGroups { get; }

    void AddCriminalRecord(CriminalRecord record);
    void RemoveCriminalRecord(CriminalRecord record);
}

public class PoliceCriminalDatabase : IPoliceCriminalDatabase
{
    private List<CriminalRecord> _criminalRecords;
    private List<CriminalGroup> _criminalGroups;

    public IReadOnlyList<CriminalRecord> CriminalRecords => _criminalRecords.AsReadOnly();
    public List<CriminalGroup> CriminalGroups => _criminalGroups;

    public PoliceCriminalDatabase()
    {
        _criminalRecords = new List<CriminalRecord>();
        _criminalGroups = new List<CriminalGroup>();
    }

    public void AddCriminalRecord(CriminalRecord record)
    {
        _criminalRecords.Add(record);
    }

    public void RemoveCriminalRecord(CriminalRecord record)
    {
        _criminalRecords.Remove(record);
    }
}

public class CrimesInsider3rdPartyCompany
{
    private readonly ICriminalRecords _database;

    public CrimesInsider3rdPartyCompany(ICriminalRecords database)
    {
        _database = database;
    }

    public CriminalRecord? GetMostDangerousCriminal()
    {
        return _database.CriminalRecords.OrderByDescending(c => c.AccusationDetails.Severity).FirstOrDefault();
    }

    public double GetAverageAgeOfCriminals()
    {
        return _database.CriminalRecords.Average(c => (DateTime.Now - c.BirthDate).TotalDays / 365.25);
    }

    public List<CriminalRecord> SortCriminalsBySeverity()
    {
        return _database.CriminalRecords.OrderBy(c => c.AccusationDetails.Severity).ToList();
    }
}

namespace PoliceDB
{
    class Program
    {
        static void Main(string[] args)
        {
            var database = new PoliceCriminalDatabase();
            var crimesInsider = new CrimesInsider3rdPartyCompany(database);

            while (true)
            {
                DisplayMenu();

                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddCriminalRecord(database);
                        break;
                    case "2":
                        DisplayMostDangerousCriminal(crimesInsider);
                        break;
                    case "3":
                        DisplayAverageAgeOfCriminals(crimesInsider);
                        break;
                    case "4":
                        DisplaySortedCriminalsBySeverity(crimesInsider);
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                        break;
                }
            }
        }

        static void DisplayMenu()
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Add a new criminal record");
            Console.WriteLine("2. Find the most dangerous criminal");
            Console.WriteLine("3. Get the average age of criminals");
            Console.WriteLine("4. Sort criminals by severity");
            Console.WriteLine("5. Exit");
            Console.Write("Choose an option (1-5): ");
        }

        static void AddCriminalRecord(IPoliceCriminalDatabase database)
        {
            Console.WriteLine("Enter details for a new criminal record:");
            var criminal = GetCriminalRecordFromUser();
            database.AddCriminalRecord(criminal);
            Console.WriteLine("Criminal record added successfully.");
        }

        static void DisplayMostDangerousCriminal(CrimesInsider3rdPartyCompany crimesInsider)
        {
            var mostDangerousCriminal = crimesInsider.GetMostDangerousCriminal();
            Console.WriteLine("Most Dangerous Criminal:");
            Console.WriteLine(mostDangerousCriminal != null ? $"Name: {mostDangerousCriminal.Name}, Severity: {mostDangerousCriminal.AccusationDetails.Severity}" : "No criminal records available.");
        }

        static void DisplayAverageAgeOfCriminals(CrimesInsider3rdPartyCompany crimesInsider)
        {
            var averageAge = crimesInsider.GetAverageAgeOfCriminals();
            Console.WriteLine($"Average Age of Criminals: {averageAge:F2} years");
        }

        static void DisplaySortedCriminalsBySeverity(CrimesInsider3rdPartyCompany crimesInsider)
        {
            var sortedCriminals = crimesInsider.SortCriminalsBySeverity();
            Console.WriteLine("Sorted Criminals by Severity:");
            foreach (var criminal in sortedCriminals)
            {
                Console.WriteLine($"Name: {criminal.Name}, Severity: {criminal.AccusationDetails.Severity}");
            }
        }

        static CriminalRecord GetCriminalRecordFromUser()
        {
            Console.Write("Enter name: ");
            string name = Console.ReadLine();

            Console.Write("Enter nickname: ");
            string nickname = Console.ReadLine();

            DateTime birthDate;
            while (true)
            {
                Console.Write("Enter birth date (yyyy-mm-dd): ");
                if (DateTime.TryParse(Console.ReadLine(), out birthDate))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid date format. Please try again.");
                }
            }

            Console.Write("Enter type of crime (Theft, Assault, Fraud, Homicide): ");
            CrimeType crimeType;
            while (!Enum.TryParse(Console.ReadLine(), true, out crimeType))
            {
                Console.WriteLine("Invalid crime type. Please enter one of the following: Theft, Assault, Fraud, Homicide.");
            }

            Console.Write("Enter crime severity (Low, Medium, High, LifeThreatening): ");
            CrimeSeverity crimeSeverity;
            while (!Enum.TryParse(Console.ReadLine(), true, out crimeSeverity))
            {
                Console.WriteLine("Invalid crime severity. Please enter one of the following: Low, Medium, High, LifeThreatening.");
            }

            Console.Write("Enter description of the crime: ");
            string description = Console.ReadLine();

            var accusation = new Accusation(crimeType, crimeSeverity, description, DateTime.Now);
            return new CriminalRecord(name, nickname, birthDate, accusation, null);
        }
    }
}
