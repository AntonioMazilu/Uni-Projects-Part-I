﻿using System;
using System.Collections.Generic;

// Interfaces for Prototype and Blueprints
public interface IPrototype<T>
{
    T Clone();
}

public interface IWeaponBlueprint
{
    string name { get; set; }
}

public interface IBombBlueprint : IWeaponBlueprint { }
public interface IConventionalArtilleryBlueprint : IWeaponBlueprint { }
public interface IGuideProjectileArtilleryBlueprint : IWeaponBlueprint { }
public interface IMortarBlueprint : IWeaponBlueprint { }
public interface IRocketArtilleryBlueprint : IWeaponBlueprint { }

// Interfaces for Weapon Parts
public interface IMetalCasing { }
public interface IPropulsionChemical { }
public interface IGuidanceKit { }
public interface IExplosiveContent { }
public interface IProjectileLauncher { }
public interface IProjectileDetonation { }

// Abstract Factory for Weapon Parts
public interface IAbstractWeaponFactory
{
    IMetalCasing CreateMetalCasing();
    IPropulsionChemical CreatePropulsionChemical();
    IGuidanceKit CreateGuidanceKit();
    IExplosiveContent CreateExplosiveContent();
    IProjectileLauncher CreateProjectileLauncher();
    IProjectileDetonation CreateProjectileDetonation();
}

public class CMetalCasingFactory : IAbstractWeaponFactory
{
    public IMetalCasing CreateMetalCasing() => new MetalCasing();
    public IPropulsionChemical CreatePropulsionChemical() => null;
    public IGuidanceKit CreateGuidanceKit() => null;
    public IExplosiveContent CreateExplosiveContent() => null;
    public IProjectileLauncher CreateProjectileLauncher() => null;
    public IProjectileDetonation CreateProjectileDetonation() => null;
}

public class CPropulsionFactory : IAbstractWeaponFactory
{
    public IMetalCasing CreateMetalCasing() => null;
    public IPropulsionChemical CreatePropulsionChemical() => new PropulsionChemical();
    public IGuidanceKit CreateGuidanceKit() => null;
    public IExplosiveContent CreateExplosiveContent() => null;
    public IProjectileLauncher CreateProjectileLauncher() => null;
    public IProjectileDetonation CreateProjectileDetonation() => null;
}

public class CGuidanceFactory : IAbstractWeaponFactory
{
    public IMetalCasing CreateMetalCasing() => null;
    public IPropulsionChemical CreatePropulsionChemical() => null;
    public IGuidanceKit CreateGuidanceKit() => new GuidanceKit();
    public IExplosiveContent CreateExplosiveContent() => null;
    public IProjectileLauncher CreateProjectileLauncher() => null;
    public IProjectileDetonation CreateProjectileDetonation() => null;
}

public class CExplosiveChemicalsFactory : IAbstractWeaponFactory
{
    public IMetalCasing CreateMetalCasing() => null;
    public IPropulsionChemical CreatePropulsionChemical() => null;
    public IGuidanceKit CreateGuidanceKit() => null;
    public IExplosiveContent CreateExplosiveContent() => new ExplosiveContent();
    public IProjectileLauncher CreateProjectileLauncher() => null;
    public IProjectileDetonation CreateProjectileDetonation() => null;
}

public class CWeaponLaunchPlatformFactory : IAbstractWeaponFactory
{
    public IMetalCasing CreateMetalCasing() => null;
    public IPropulsionChemical CreatePropulsionChemical() => null;
    public IGuidanceKit CreateGuidanceKit() => null;
    public IExplosiveContent CreateExplosiveContent() => null;
    public IProjectileLauncher CreateProjectileLauncher() => new ProjectileLauncher();
    public IProjectileDetonation CreateProjectileDetonation() => new ProjectileDetonation();
}

// Concrete Classes for Weapon Parts
public class MetalCasing : IMetalCasing { }
public class PropulsionChemical : IPropulsionChemical { }
public class GuidanceKit : IGuidanceKit { }
public class ExplosiveContent : IExplosiveContent { }
public class ProjectileLauncher : IProjectileLauncher { }
public class ProjectileDetonation : IProjectileDetonation { }

// Interface and Concrete Classes for Weapons
public interface IWeapon
{
    void Identify();
    void Use();
}

public class Bomb : IWeapon
{
    public void Identify() => Console.WriteLine("Bomb identified.");
    public void Use() => Console.WriteLine("Bomb used.");
}

public class ConventionalArtillery : IWeapon
{
    public void Identify() => Console.WriteLine("Conventional Artillery identified.");
    public void Use() => Console.WriteLine("Conventional Artillery used.");
}

// Builder for Weapon
public interface IWeaponBuilder
{
    void BuildMetalCasing();
    void BuildPropulsionChemical();
    void BuildGuidanceKit();
    void BuildExplosiveContent();
    void BuildProjectileLauncher();
    void BuildProjectileDetonation();
    IWeapon GetWeapon();
}

public class BombBuilder : IWeaponBuilder
{
    private Bomb _bomb = new Bomb();
    private IAbstractWeaponFactory _factory;

    public BombBuilder(IAbstractWeaponFactory factory) => _factory = factory;

    public void BuildMetalCasing() => _factory.CreateMetalCasing();
    public void BuildPropulsionChemical() => _factory.CreatePropulsionChemical();
    public void BuildGuidanceKit() => _factory.CreateGuidanceKit();
    public void BuildExplosiveContent() => _factory.CreateExplosiveContent();
    public void BuildProjectileLauncher() => _factory.CreateProjectileLauncher();
    public void BuildProjectileDetonation() => _factory.CreateProjectileDetonation();
    public IWeapon GetWeapon() => _bomb;
}

// Director for Weapon Creation
public class ArmyFactory
{
    public IWeapon CreateWeapon(IWeaponBuilder builder)
    {
        builder.BuildMetalCasing();
        builder.BuildPropulsionChemical();
        builder.BuildGuidanceKit();
        builder.BuildExplosiveContent();
        builder.BuildProjectileLauncher();
        builder.BuildProjectileDetonation();
        return builder.GetWeapon();
    }
}

// Client
public class ArmyCommand
{
    private ArmyFactory _armyFactory = new ArmyFactory();

    public void OrderWeapon(IWeaponBuilder builder)
    {
        var weapon = _armyFactory.CreateWeapon(builder);
        weapon.Identify();
        weapon.Use();
    }
}

// Example Usage
class Program
{
    static void Main(string[] args)
    {
        IAbstractWeaponFactory bombFactory = new CMetalCasingFactory();
        IWeaponBuilder bombBuilder = new BombBuilder(bombFactory);
        ArmyCommand armyCommand = new ArmyCommand();

        armyCommand.OrderWeapon(bombBuilder);
    }
}