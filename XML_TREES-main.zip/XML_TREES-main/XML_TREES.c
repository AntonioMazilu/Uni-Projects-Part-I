//ION ANTONIO MAZILU A.M 2022202000131
//EMMANOUHL SXOINOPLOKAKHS A.M 2022202000204


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define size 1800
#define n 5

typedef struct tree
{   
    char *tag;
    struct tree** kids;
} *tree;

tree parse(tree parseroot,char *tag, int num);
void printtree(tree parseroot);

int main() 
{
    FILE *ptr;
    char array[size] = "\0";
    int i, j, k, d;
    char word, c, a;

    struct tree *root = NULL;

    ptr = fopen("sample.xml", "r");
    if (!ptr) 
    {
        printf("error\n");
        exit(0);
    }   
    else
    {
        printf("ok\n");
    } 

    while (!feof(ptr))
    {
        c = fgetc(ptr);
        for (i = 0; i < size; i++) {
            if (array[i] == 0) {
                array[i] = (char) c;
                break;
            }
        }   
    }

    int sum1 = 0, sum2 = 0, ela = 0;
    for (i = 0; i < size; i++) {
        if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 'c' && array[i + 2] == 'a' && array[i + 3] == 't' && array[i + 4] == 'a' && array[i + 5] == 'l' && array[i + 6] == 'o' && array[i + 7] == 'g') {
            sum1++;
            root = parse(root, "catalog", -1);
        } else if (array[i] == '<' && array[i + 1] == '/' && array[i + 2] == 'c' && array[i + 3] == 'a' && array[i + 4] == 't' && array[i + 5] == 'a' && array[i + 6] == 'l' && array[i + 7] == 'o' && array[i + 8] == 'g') {
            sum1++;
        } else if (array[i] == '<' && (array[i + 1] != '/' || array[i + 1] == '/') && array[i + 1] == 'b' && array[i + 2] == 'o' && array[i + 3] == 'o' && array[i + 4] == 'k') {
            sum2++;
        }

        if (sum1 == 2) {
            // printf("end\n");
            break;
        }
        if (sum2 == 1) {

            if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 'a' && array[i + 2] == 'u' && array[i + 3] == 't' && array[i + 4] == 'h' && array[i + 5] == 'o' && array[i + 6] == 'r' && array[i + 7] == '>') {
                for (j = i; j < size; j++) {
                    if (array[j] == '<' && array[j + 1] == '/' && array[j + 2] == 'a' && array[j + 3] == 'u' && array[j + 4] == 't' && array[j + 5] == 'h' && array[j + 6] == 'o' && array[j + 7] == 'r' && array[j + 8] == '>') {
                        root = parse(root, "author", 0);
                        break;
                    }
                }
            } else if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 't' && array[i + 2] == 'i' && array[i + 3] == 't' && array[i + 4] == 'l' && array[i + 5] == 'e' && array[i + 6] == '>') {
                for (j = i; j < size; j++) {
                    if (array[j] == '<' && array[j + 1] == '/' && array[j + 2] == 't' && array[j + 3] == 'i' && array[j + 4] == 't' && array[j + 5] == 'l' && array[j + 6] == 'e' && array[j + 7] == '>') {
                        root = parse(root, "title", 1);
                        break;
                    }
                }
            } else if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 'g' && array[i + 2] == 'e' && array[i + 3] == 'n' && array[i + 4] == 'r' && array[i + 5] == 'e' && array[i + 6] == '>') {
                for (j = i; j < size; j++) {
                    if (array[j] == '<' && array[j + 1] == '/' && array[j + 2] == 'g' && array[j + 3] == 'e' && array[j + 4] == 'n' && array[j + 5] == 'r' && array[j + 6] == 'e' && array[j + 7] == '>') {
                        root = parse(root, "genre", 2);
                        break;
                    }
                }
            } else if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 'p' && array[i + 2] == 'r' && array[i + 3] == 'i' && array[i + 4] == 'c' && array[i + 5] == 'e' && array[i + 6] == '>') {
                for (j = i; j < size; j++) {
                    if (array[j] == '<' && array[j + 1] == '/' && array[j + 2] == 'p' && array[j + 3] == 'r' && array[j + 4] == 'i' && array[j + 5] == 'c' && array[j + 6] == 'e' && array[j + 7] == '>') {
                        root = parse(root, "price", 3);
                        break;
                    }
                }
            } else if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 'd' && array[i + 2] == 'a' && array[i + 3] == 't' && array[i + 5] == 'e' && array[i + 6] == '>') {
                for (j = i; j < size; j++) {
                    if (array[j] == '<' && array[j + 1] == '/' && array[j + 2] == 'd' && array[j + 3] == 'a' && array[j + 4] == 't' && array[j + 6] == 'e' && array[j + 7] == '>') {
                        root = parse(root, "date", 4);
                        break;
                    }
                }
            } else if (array[i] == '<' && array[i + 1] != '/' && array[i + 1] == 'd' && array[i + 2] == 'e' && array[i + 3] == 's' && array[i + 4] == 'c' && array[i + 5] == 'r' && array[i + 6] == 'i' && array[i + 7] == 'p' && array[i + 8] == 't' && array[i + 9] == 'i' && array[i + 10] == 'o' && array[i + 11] == 'n' && array[i + 12] == '>') {
                for (j = i; j < size; j++) {
                    if (array[j] == '<' && array[j + 1] == '/' && array[j + 2] == 'd' && array[j + 3] == 'e' && array[j + 4] == 's' && array[j + 5] == 'c' && array[j + 6] == 'r' && array[j + 7] == 'i' && array[j + 8] == 'p' && array[j + 9] == 't' && array[j + 10] == 'i' && array[j + 11] == 'o' && array[j + 12] == 'n' && array[j + 13] == '>') {
                        root = parse(root, "description", 5);
                        sum2++;
                        break;
                    }
                }
            }
            // printf("\n");
        }


        if (sum2 == 2)
        {
            sum2 = 0;
        }
    }

    printtree(root);

    fclose(ptr);

    return 0;
}

tree parse(tree parseroot, char *tag, int num)
{
    int i;
    if (parseroot == NULL) 
    {
        parseroot = malloc(sizeof(tree));
        parseroot->kids = malloc(n * sizeof(struct tree));
    
        for (int i=0;i<n;i++)
        {
            parseroot->kids[i] = NULL;
        }

        return parseroot;
    } 
    else
    {
        if (num != -1)
            parseroot->kids[num] = tag;
    }

    return parseroot;
}

void printtree(tree parseroot) 
{   
    for (int i = 0; i < n + 1; i++) 
        printf("<%s>\n", parseroot->kids[i]);
}