<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole === 'administrator') 
        {
            header('Location: ./admin.php');
            exit();
        }
    }
?>

<!DOCTYPE html5>
<html lang="el">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Εράσμους Πρόγραμμα">
    <title>Αρχική</title>
    <link rel="icon" href="./media/erasmus+.png">
    <link rel="stylesheet" href="./styles/more.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="./scripts/index.js"></script>
  </head>

  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <a href="index.php">Αρχική</a>
          <?php if ($userRole === 'visitor') { ?>
            <a href="login.php">Σύνδεση</a>
            <a href="sign-up.php">Εγγραφή</a>
          <?php } ?>
        <a class="active" href="more.php">Πληροφορίες</a>
          <?php if ($userRole === 'regular') { ?>
            <a href="application.php">Φόρμα αίτησης</a>
          <?php } ?> 
        <a href="reqs.php">Προαπαιτούμενες απαιτήσεις</a>
          <?php if ($userRole === 'administrator') { ?>
            <a href="admin.php">Admin</a>
          <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
              <div class="topnav">
                  <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
                  <a href="logout.php">Αποσύνδεση</a>
              </div>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Πληροφορίες</h1>
          </header>
          <div class="paragraph">

            <h3>1. Τι είναι το Erasmus+;</h3>

            <p>
                Το Erasmus+ είναι το πρόγραμμα της ΕΕ για τη στήριξη της εκπαίδευσης, της κατάρτισης, της νεολαίας και του αθλητισμού στην Ευρώπη.
                Το πρόγραμμα 2021-2027 δίνει ιδιαίτερη έμφαση στην κοινωνική ένταξη, στην πράσινη και στην ψηφιακή μετάβαση, καθώς και στην προώθηση της συμμετοχής των νέων στον δημοκρατικό βίο.
            </p>

            <h3>2. Ποιές είναι οι βασικές δράσεις του Erasmus+;</h3>

            <p>
                 Το Erasmus+ χωρίζεται σε 3 Βασικές Δράσεις για τους τομείς Εκπαίδευση, Κατάρτιση και Νεολαία. Οι Βασικές Δράσεις είναι:
                * Κινητικότητα των ατόμων.
                * Συνεργασία για την καινοτομία και την ανταλλαγή καλών πρακτικών.
                * Ενίσχυση σε θέματα μεταρρυθμίσεων πολιτικής.
            </p>


            <h3> 3. Ποιοί είναι οι στόχοι του προγράμματος;</h3>
            <p>    
                Το πρόγραμμα:
                * προάγει τη μαθησιακή κινητικότητα ατόμων και ομάδων, καθώς και τη συνεργασία, την ποιότητα, την ένταξη και την ισότητα, την αριστεία, τη δημιουργικότητα και την καινοτομία σε επίπεδο οργανώσεων και πολιτικών στον τομέα της εκπαίδευσης και της κατάρτισης·
                * προάγει την κινητικότητα στον τομέα της μη τυπικής και άτυπης μάθησης και την ενεργό συμμετοχή των νέων, καθώς και τη συνεργασία, την ποιότητα, την ένταξη, τη δημιουργικότητα και την καινοτομία σε επίπεδο οργανώσεων και πολιτικών στον τομέα της νεολαίας·
                * προάγει τη μαθησιακή κινητικότητα του προσωπικού στον χώρο του αθλητισμού, καθώς και τη συνεργασία, την ποιότητα, την ένταξη, τη δημιουργικότητα και την καινοτομία σε επίπεδο οργανώσεων και πολιτικών στον τομέα του αθλητισμού.

            </p>


            <h3>4. Σε ποιούς απευθύνεται το Erasmus+;</h3>

            <p>
                Κατά γενικό κανόνα, οι συμμετέχοντες σε έργα Erasmus+ πρέπει να μένουν σε κράτος μέλος της ΕΕ ή τρίτη χώρα συνδεδεμένη με το Πρόγραμμα. Ορισμένες Δράσεις, ιδίως στους τομείς της τριτοβάθμιας εκπαίδευσης, της επαγγελματικής εκπαίδευσης και κατάρτισης, της νεολαίας και του αθλητισμού, είναι επίσης ανοικτές σε συμμετέχοντες από τρίτες χώρες που δεν συνδέονται με το πρόγραμμα.


                Οι ειδικές προϋποθέσεις για τη συμμετοχή σε ένα έργο Erasmus+ εξαρτώνται από το είδος της σχετικής Δράσης.
                Οι κύριες ομάδες-στόχοι είναι:
                * φοιτητές τριτοβάθμιας εκπαίδευσης (μικρός κύκλος, πρώτος, δεύτερος ή τρίτος κύκλος), 
                * καθηγητές και καθηγητές τριτοβάθμιας εκπαίδευσης, 
                * προσωπικό ιδρυμάτων τριτοβάθμιας εκπαίδευσης.
            </p>

            <br>
            <br>
            <p>Παρακολουθήστε τα παρακάτω βιντεάκια Erasmus!!</p>
            <video description="ErasmusVideo" width="320" height="240" controls>
                <source src="./media/Erasmus Programme in Greece_ IKY-Hellenic LLP National Agency.mp4" type=video/mp4>
            </video>
            <br>
            <br>
            <h3><a href="https://youtu.be/vZzk0kPOugc">Περισσότερα για το Erasmus+ Στην Ελλάδα</a></h3>
            <br>
            <br>
            <h3> Κριτικές φοιτητών</h3>
            <p>Η εμπειρία του Erasmus είναι μοναδική. <br>
            Δεν νομίζουμε ότι μπορεί να περιγραφεί με λόγια. 
            Έχεις την ευκαιρία να γνωρίσεις διαφορετικούς λαούς , 
            να κάνεις φίλους από όλη την Ευρώπη και να αναθεωρήσεις 
            απόψεις λανθασμένες και μη που είχες πριν από αυτή την πρακτική…» <br>
            Θωμάς Σταφύλας & Μάρθα Μπάμπη, Πρακτική Άσκηση Erasmus στην Πορτογαλία</p>
            <br>
            <div class="images">
                <div class="image-row">
                  <img src="./media/erasmus_portogalia.png" alt="ErasmusPortogalia">
                </div>
            </div>
            <br>
          <div>
          <div class="images">
            <div class="image-row">
              <img src="./media/uopeu.png" alt="UopEUerasmus">
            </div>
          </div>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>
