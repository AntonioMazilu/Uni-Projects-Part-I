<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole === 'administrator') 
        {
            header('Location: ./admin.php');
            exit();
        }
        if ($userRole === 'regular') 
        {
            header('Location: ./index.php');
            exit();
        }
    }
?>

<!DOCTYPE html5>
  <html lang="el">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="Φόρμα Αίτησης σε Erasmus+">
      <title>Εγγραφή</title>
      <link rel="icon" href="./media/erasmus+.png">
      <link rel="stylesheet" href="./styles/sign-up.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
      <script src="./scripts/index.js"></script>
      <script src="./scripts/signup_check.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <a href="index.php">Αρχική</a>
        <?php if ($userRole === 'visitor') { ?>
          <a href="login.php">Σύνδεση</a>
        <?php } ?>
        <a class="active" href="sign-up.php">Εγγραφή</a>
        <a href="more.php">Πληροφορίες</a>
        <?php if ($userRole === 'regular') { ?>
            <a href="application.php">Φόρμα αίτησης</a>
        <?php } ?>
        <a href="reqs.php">Προαπαιτούμενες απαιτήσεις</a>
        <?php if ($userRole === 'administrator') { ?>
            <a href="admin.php">Admin</a>
        <?php } ?>
        <div class="user-section" style="float:right">
            <?php if (isset($_SESSION['username'])) { ?>
                <div class="topnav">
                    <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
                    <a href="logout.php">Αποσύνδεση</a>
                </div>
            <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Εγγραφή</h1>
          </header>
          <div class="form">
            <form id="signup" method ="POST">
              <br>
              <label for="όνομα">Όνομα</label><br>
              <input type="text" id="όνομα" name="όνομα" placeholder="π.χ. Κωνσταντίνος" required>
              <br>
              <br>
              <label for="επίθετο">Επίθετο</label><br>
              <input type="text" id="επίθετο" name="επίθετο" placeholder="π.χ. Ντούρος" required>
              <br>
              <br>
              <label for="αριθμός_μητρώου">Αριθμός Μητρώου</label><br>
              <input type="number" id="αριθμός_μητρώου" name="αριθμός_μητρώου" placeholder="π.χ. 2022XXXXXXXXX" required>
              <br>
              <br>
              <label for="τηλέφωνο">Τηλέφωνο Επικοινωνίας</label><br>
              <input type="number" id="τηλέφωνο" name="τηλέφωνο" placeholder="π.χ. 69ΧΧΧΧΧΧΧΧ" required>
              <br>
              <br>
              <label for="email">Email</label><br>
              <input type="email" id="email" name="email" placeholder="π.χ. dit20XXX@go.uop.gr" required>
              <br>
              <br>
              <label for="username">Username</label><br>
              <input type="text" id="username" name="username" placeholder="π.χ. KostasNtouros" required>
              <br>
              <br>
              <label for="password">Κωδικός Πρόσβασης</label><br>
              <input type="password" id="password" name="password" placeholder="Κωδικός Πρόσβασης" required>
              <br>
              <label for="password2">Επιβεβαίωση Κωδικού Πρόσβασης</label><br>
              <input type="password" id="password2" name="password2" placeholder="Επιβεβαίωση Κωδικού Πρόσβασης" required>
              <br>
              <br>
              <label for="checkbox">Αποδοχή των όρων</label>
              <input type="checkbox" id="checkbox" name="checkbox" required/>
              <br>
              <br>
              <input type="submit" id="submit" name="submit" value="Εγγραφή">
            </form>
          </div>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>