<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole === 'administrator') 
        {
            header('Location: ./admin.php');
            exit();
        }
    }
?>

<!DOCTYPE html5>
<html lang="el">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Εράσμους Πρόγραμμα">
    <title>Αρχική</title>
    <link rel="icon" href="./media/erasmus+.png">
    <link rel="stylesheet" href="./styles/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="./scripts/index.js"></script>
  </head>

  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <a class="active" href="index.php">Αρχική</a>
          <?php if ($userRole === 'visitor') { ?>
            <a href="login.php">Σύνδεση</a>
            <a href="sign-up.php">Εγγραφή</a>
          <?php } ?>
        <a href="more.php">Πληροφορίες</a>
          <?php if ($userRole === 'regular') { ?>
            <a href="application.php">Φόρμα αίτησης</a>
          <?php } ?> 
        <a href="reqs.php">Προαπαιτούμενες απαιτήσεις</a>
          <?php if ($userRole === 'administrator') { ?>
            <a href="admin.php">Admin</a>
          <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
              <div class="topnav">
                  <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
                  <a href="logout.php">Αποσύνδεση</a>
              </div>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Πρόγραμμα Erasmus+ <br> Πανεπιστήμιο Πελοποννήσου <br> Πληροφορικής και Τηλεπικοινωνιών</h1>
          </header>
          <div class="paragraph">
            <p>Είστε έτοιμοι να πάτε την εκπαίδευση και τις εμπειρίες σας στο επόμενο επίπεδο; 
              Αυτό μπορεί πλέον να γίνει μέσω του Erasmus+, ένα πρόγραμμα που υποστηρίζεται από την Ευρωπαϊκή Ένωση και είναι το διαβατήριό σας για τον κόσμο, παρέχοντάς σας απαράμιλλες ευκαιρίες για σπουδές, εκπαίδευση, απόκτηση εμπειρίας και εθελοντισμό στο εξωτερικό.</p>
              
              <p>Συμμετέχοντας στο Erasmus+:
                <br>
              -θα αποκτήσετε ανεκτίμητες γνώσεις και δεξιότητες που θα σας φανούν χρήσιμες σε όλη τη διάρκεια της ζωής και της καριέρας σας. 
              <br>
              -Θα μάθετε για νέους πολιτισμούς, 
              <br>
              -θα γνωρίσετε ανθρώπους από όλο τον κόσμο
              <br>
              -θα διευρύνετε τους ορίζοντές σας με τρόπους που ποτέ δεν φανταζόσασταν δυνατοί.<br></p>
              
              <p>Το πανεπιστήμιο μας μπορεί να σας παρέχει την καλύτερη δυνατή εμπειρία Erasmus+. 
              Τα προγράμματά μας έχουν σχεδιαστεί προσεκτικά για να καλύπτουν τις ανάγκες σας και θα συνεργαστούμε στενά μαζί σας για να διασφαλίσουμε ότι θα αξιοποιήσετε στο έπακρο τον χρόνο σας στο εξωτερικό. 
              Πιστεύουμε ότι κάθε φοιτητής αξίζει μια ευκαιρία να συμμετάσχει στο Erasmus+ και δεσμευόμαστε να σας βοηθήσουμε να κάνετε τα όνειρά σας πραγματικότητα.</p>
              
              <p>Λοιπόν, τι περιμένεις; 
              Κάντε το πρώτο βήμα για μια αξέχαστη εμπειρία εξερευνώντας τη σελίδα μας στο Erasmus+ σήμερα! 
              Είμαστε εδώ για να σας βοηθήσουμε σε κάθε βήμα, από το να απαντήσουμε στις ερωτήσεις σας μέχρι να σας καθοδηγήσουμε στη διαδικασία υποβολής αίτησης. 
              Μαζί, ας κάνουμε πραγματικότητα την περιπέτειά σας στο Erasmus+!</p>
          </div>
          <div class="images">
            <div class="image-row">
              <img src="./media/uopeu.png" alt="UopEUerasmus">
            </div>
          </div>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>
