<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole !== 'administrator') 
        {
            header('Location: ../index.php');
            exit();
        }
    }
    else
    {
        header('Location: ../index.php');
        exit();
    }
?>

<!DOCTYPE html5>
<html lang="el">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Φόρμα Αίτησης σε Erasmus+">
    <title>Εμφάνιση Διαχειριστών</title>
    <link rel="icon" href="../media/erasmus+.png">
    <link rel="stylesheet" href="../styles/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="../scripts/index.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <?php if ($userRole === 'administrator') { ?>
          <a href="../admin.php">Admin</a>
          <a class="active" href="get_administrators.php">Εμφανιση Διαχειριστών</a>
          <a href="get_universities.php">Eμφάνιση Πανεπιστημίων</a>
          <a href="new_university.php">Προσθήκη Πανεπιστημίου</a>
          <a href="new_administrator.php">Προσθήκη Διαχειριστή</a>
          <a href="period-applications.php">Περιοδος Αιτήσεων</a>
          <a href="getAllApplications.php">Εμφανιση Αιτήσεων</a>
          <div id="submenu">
            <a href="">Εμφανιση Δεκτών Αιτήσεων</a>
          </div>
        <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
            <div class="topnav">
              <a href=""><?php echo $_SESSION['username']; ?></a>
              <a href="../logout.php">Αποσύνδεση</a>
            </div>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>
<?php
  include '../php_files/config.php';

  $checkQuery = "SELECT users.fname, users.lname, users.username,users.tel, users.email, users.password FROM users WHERE users.user_type_id = 2";
  $checkStmt = $conn->prepare($checkQuery);
  $checkStmt->execute();
  $checkResult = $checkStmt->get_result();

  if ($checkResult->num_rows > 0) 
  {
      // Display table headers
      echo '<table border="1">';
          
      // Table header
      echo '<tr>';
      echo '<th>First Name</th>';
      echo '<th>Last Name</th>';
      echo '<th>Username</th>';
      echo '<th>Phone Number</th>';
      echo '<th>Email</th>';
      echo '<th>Password</th>';
      echo '</tr>';

      while ($row = $checkResult->fetch_assoc()) 
      {
          // Display table rows with application information
          echo "<tr>";
          echo "<td>" . $row['fname'] . "</td>";
          echo "<td>" . $row['lname'] . "</td>";
          echo "<td>" . $row['username'] . "</td>";
          echo "<td>" . $row['tel'] . "</td>";
          echo "<td>" . $row['email'] . "</td>";
          echo "<td>" . $row['password'] . "</td>";
          echo "</tr>";
      }

      echo "</table>";
  } 
  else 
  {
      echo "No applications found.";
  }

  $conn->close();
?>