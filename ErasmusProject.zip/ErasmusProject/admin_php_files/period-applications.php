<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole !== 'administrator') 
        {
            header('Location: ../index.php');
            exit();
        }
    }
    else
    {
        header('Location: ../index.php');
        exit();
    }
?>

<!DOCTYPE html5>
<html lang="el">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Φόρμα Αίτησης σε Erasmus+">
    <title>Περίοδος Αιτήσεων</title>
    <link rel="icon" href="../media/erasmus+.png">
    <link rel="stylesheet" href="../styles/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="../scripts/index.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <?php if ($userRole === 'administrator') { ?>
          <a href="../admin.php">Admin</a>
          <a href="get_administrators.php">Εμφανιση Διαχειριστών</a>
          <a href="get_universities.php">Eμφάνιση Πανεπιστημίων</a>
          <a href="new_university.php">Προσθήκη Πανεπιστημίου</a>
          <a href="new_administrator.php">Προσθήκη Διαχειριστή</a>
          <a class="active" href="period-applications.php">Περιοδος Αιτήσεων</a>
          <a href="getAllApplications.php">Εμφανιση Αιτήσεων</a>
          <div id="submenu">
            <a href="">Εμφανιση Δεκτών Αιτήσεων</a>
          </div>
        <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
            <div class="topnav">
              <a href=""><?php echo $_SESSION['username']; ?></a>
              <a href="../logout.php">Αποσύνδεση</a>
            </div>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Περιοδος Αιτησεων</h1>
          </header>
          <div class="form">
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" required>

                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" required>

                <input type="submit" id="submit" name="submit" value="Υποβολή">
            </form>
          </div>
          <?php
            include '../php_files/config.php';

            if (isset($_POST["submit"])) 
            {
                // Get the current date
                $currentDate = date('Y-m-d');

                // Get the start and end dates submitted from the form
                $start_date = $_POST['start_date'];
                $end_date = $_POST['end_date'];

                if ($currentDate < $start_date || $currentDate > $end_date) 
                {
                    echo "Application period is not currently active.";
                } 
                else if ($start_date > $end_date) 
                {
                    echo "Invalid date range. Please select a valid date range.";
                } 
                else 
                {
                    // Process the application form
                    // Add your code to handle the form submission and save the application data
                    echo "Application submitted successfully.";
                }
            }

            $conn->close();
          ?>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>