<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole !== 'administrator') 
        {
            header('Location: ./index.php');
            exit();
        }
    }
    else
    {
        header('Location: ./index.php');
        exit();
    }
?>

<!DOCTYPE html5>
<html lang="el">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Φόρμα Αίτησης σε Erasmus+">
    <title>Admin</title>
    <link rel="icon" href="./media/erasmus+.png">
    <link rel="stylesheet" href="./styles/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="./scripts/index.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <a class="active" href="admin.php">Admin</a>
        <?php if ($userRole === 'administrator') { ?>
          <a href="./admin_php_files/get_administrators.php">Εμφανιση Διαχειριστών</a>
          <a href="./admin_php_files/get_universities.php">Eμφάνιση Πανεπιστημίων</a>
          <a href="./admin_php_files/new_university.php">Προσθήκη Πανεπιστημίου</a>
          <a href="./admin_php_files/new_administrator.php">Προσθήκη Διαχειριστή</a>
          <a href="./admin_php_files/period-applications.php">Περιοδος Αιτήσεων</a>
          <a href="./admin_php_files/getAllApplications.php">Εμφανιση Αιτήσεων</a>
          <div id="submenu">
            <a href="">Εμφανιση Δεκτών Αιτήσεων</a>
          </div>
        <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
            <div class="topnav">
              <a href=""><?php echo $_SESSION['username']; ?></a>
              <a href="logout.php">Αποσύνδεση</a>
            </div>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Πρόγραμμα Erasmus+ Admin Panel <br> Πανεπιστήμιο Πελοποννήσου <br> Πληροφορικής και Τηλεπικοινωνιών</h1>
          </header>
          <div class="paragraph">
            <p>Εδώ μπορείτε να διαχειριστείτε τις πληροφρίες για το Πρόγραμμα Erasmus</p>
              
              <p>Λειτουργίες:</p>
              -Προσθήκη Διαχειριστή. 
              <br>
              <br>
              -Προσθήκη συνεργαζόμενων Πανεπιστημίων. 
              <br>
              <br>
              -Προσθήκη Περιόδων Αιτήσεων.
              <br>
              <br>
              -Προβολή αιτήσεων φοιτητών.
              <br>
              <br>
              -Προβολή συνεργαζόμενων Πανεπιστημίων.
              <br>
              <br>
              -Προβολή διαχειριστών.
              <br>
              <br>
              -Προβολή δεκτών αιτήσεων.
          <div>
          <div class="images">
            <div class="image-row">
              <img src="./media/uopeu.png" alt="UopEUerasmus">
            </div>
          </div>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>