<?php
include 'config.php';

// Initialize the response array
$response = array();

$name = $_POST['όνομα'];
$surname = $_POST['επίθετο'];
$am = $_POST['αριθμός_μητρώου'];
$phone = $_POST['τηλέφωνο'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

if ($name && $surname && $am && $phone && $email && $username && $password) 
{

    $checkQuery = "SELECT * FROM users WHERE a_m = ? OR tel = ? OR email = ? OR username = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("ssss", $am, $phone, $email, $username);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) 
    {
        $response = array('success' => false, 'message' => 'Υπάρχει ήδη άτομο με τέτοιο αριθμό μητρώου ή τηλέφωνο ή email: ' . $checkStmt->error);
    } 
    else 
    {
        //Αυτό έχει μπει προσωρινά έτσι ώστε να μπορούμε έυκολα να προσθέτουμε
        //διαχειριστές από την signup την αρχική, σε περιπτώσεις όπου
        //έχουμε σβήσει την βάση και δεν υπάρχει κάποιος ήδη υπάρχων διαχειριστής.
        // if ($am == 2022999999999) 
        // {
        //     $type = 2;
        //     $typeName = "administrator";
        // } 
        // else 
        // {
        //     $type = 1;
        //     $typeName = "regular";
        // }

        $type = 1;
        $typeName = "regular";

        $typeQuery = "INSERT INTO type (user_type_id, user_type) VALUES (?, ?)";
        $typeStmt = $conn->prepare($typeQuery);
        $typeStmt->bind_param("is", $type, $typeName);
        $typeResult = $typeStmt->execute();

        if ($typeResult) 
        {
            $insertQuery = "INSERT INTO users (fname, lname, a_m, tel, email, username, password, user_type_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("sssssssi", $name, $surname, $am, $phone, $email, $username, $hashedPassword, $type);
            $insertResult = $insertStmt->execute();

            if ($insertResult) 
            {
                $response = array('success' => true, 'message' => 'Τα δεδομένα εισάχθησαν επιτυχώς!');
            } 
            else 
            {
                $response = array('success' => false, 'message' => 'Τα δεδομένα δεν εισάχθησαν επιτυχώς: ' . $insertStmt->error);
            }
        } 
        else 
        {
            $response = array('success' => false, 'message' => 'Πρόβλημα στην εισαγωγή τύπου χρήστη: ' . $typeStmt->error);
        }
    }
} 
else 
{
    $response = array('success' => false, 'message' => 'Παρακαλώ συμπληρώστε όλα τα πεδία!');
}

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

exit();
?>