<?php
include 'config.php';

// Get the username parameter from the AJAX request
$username = isset($_POST['username']) ? $_POST['username'] : '';

// Prepare the SQL statement to check if the username exists
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Check if the username exists
if ($result && $row = $result->fetch_assoc()) 
{
  $count = $row['count'];

  // Prepare the response as JSON
  $response = array('available' => ($count === 0));
  echo json_encode($response);
} 
else 
{
  // Error handling if the query fails
  $response = array('error' => 'Error checking username availability.');
  echo json_encode($response);
}

$conn->close();
?>
