<?php
include 'config.php';

// Initialize the response array
$response = array();

$name = $_POST['όνομα'];
$surname = $_POST['επίθετο'];
$am = $_POST['αριθμός_μητρώου'];
$phone = $_POST['τηλέφωνο'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

if ($name && $surname && $am && $phone && $email && $username && $password) 
{

    $checkQuery = "SELECT * FROM users WHERE a_m = ? OR email = ? OR tel = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("sss", $am, $email, $phone);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0)
    {
        $response = array('success' => false, 'message' => 'Υπάρχει ήδη άτομο με τέτοιο αριθμό μητρώου ή τηλέφωνο ή email: ' . $checkStmt->error); 
    }
    else
    {
        $updateQuery = "UPDATE users SET `fname` = ?, `lname` = ?, `a_m` = ?, `tel` = ?, `email` = ?, `password` = ? WHERE `username` = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("sssssss", $name, $surname, $am, $phone, $email, $hashedPassword, $username);
        $updateResult = $updateStmt->execute();
    
        if ($updateResult) 
        {
            $response = array('success' => true, 'message' => 'Τα δεδομένα εισάχθησαν επιτυχώς!');
        } 
        else 
        {
            $response = array('success' => false, 'message' => 'Τα δεδομένα δεν εισάχθησαν επιτυχώς: ' . $updateStmt->error);
        }
    }
} 
else 
{
    $response = array('success' => false, 'message' => 'Παρακαλώ συμπληρώστε όλα τα πεδία!');
}

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

exit();
?>
