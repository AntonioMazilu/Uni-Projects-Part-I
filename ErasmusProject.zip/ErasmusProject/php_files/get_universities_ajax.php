<?php
include 'config.php';

// Initialize the response array
$universities = array();

// Query your database to retrieve university options
// Include the uni_id column for the value property
$sql = "SELECT uni_id, uni_name FROM uni"; 
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

// Fetch the results and add them to the array
if ($result->num_rows > 0) 
{
    while ($row = $result->fetch_assoc()) 
    {
        $university = array(
            'value' => $row['uni_name'],
            'name' => $row['uni_name']
        );
        $universities[] = $university;
    }
}

// Set the response header as JSON
header('Content-Type: application/json');
echo json_encode($universities);

$stmt->close();

exit();
?>
