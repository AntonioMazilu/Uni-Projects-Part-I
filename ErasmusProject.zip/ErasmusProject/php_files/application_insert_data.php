<?php
include 'config.php';

if (isset($_POST["submit"])) 
{
    $name = $_POST['ονομα'];
    $surname = $_POST['επίθετο'];
    $am = $_POST['αριθμός_μητρώου'];
    $passed = $_POST['ποσοστό_περασμένων_μαθημάτων'];
    $avg_passed = $_POST['μέσος_όρος_περασμένων_μαθημάτων'];
    $englishCertificate = $_POST['gradeeng'];
    $additionalLanguage = $_POST['choose1'];
    $universityChoice1 = $_POST['uni_choice1'];
    $universityChoice2 = $_POST['uni_choice2'];
    $universityChoice3 = $_POST['uni_choice3'];
    $filegrades = $_FILES['grades']['tmp_name'];
    $filecert = $_FILES['cert']['tmp_name'];
    $filemorecert = $_FILES['moreCert']['tmp_name'];

    if ($name && $surname && $am && $passed && $avg_passed && $englishCertificate && $additionalLanguage && $filegrades && $filecert) 
    {
        $checkQuery = "SELECT * FROM content WHERE a_m = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("s", $am);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) 
        {
            // User already exists, update the data
            $updateQuery = "UPDATE content SET fname = ?, lname = ?, passed = ?, avg_passed = ?, cert = ?, extra_know = ?, `1option` = ?, `2option` = ?, `3option` = ?, detail_cert = ?, diploma_eng = ?, diploma_other = ? WHERE a_m = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("sssssssssssss", $name, $surname, $passed, $avg_passed, $englishCertificate, $additionalLanguage, $universityChoice1, $universityChoice2, $universityChoice3, $filegrades, $filecert, $filemorecert, $am);
            $updateResult = $updateStmt->execute();
            if ($updateResult) 
            {
                echo "<script>alert('Τα δεδομένα ενημερώθηκαν επιτυχώς!')</script>";
                // Remove current files
                $folderPath = "../uploads/" . $am . "/";
                removeFiles($folderPath);
                // Upload new files
                uploadFiles($folderPath);
                header('Location: ../index.php');
                exit();
            } 
            else 
            {
                echo "Error updating data: " . $updateStmt->error;
                echo "<script>alert('Τα δεδομένα δεν ενημερώθηκαν επιτυχώς!')</script>";
                header('Location: ../index.php');
                exit();
            }
        } 
        else 
        {
            // User doesn't exist, insert the data
            $insertQuery = "INSERT INTO content (fname, lname, a_m, passed, avg_passed, cert, extra_know, `1option`, `2option`, `3option`, detail_cert, diploma_eng, diploma_other) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("sssssssssssss", $name, $surname, $am, $passed, $avg_passed, $englishCertificate, $additionalLanguage, $universityChoice1, $universityChoice2, $universityChoice3, $filegrades, $filecert, $filemorecert);
            $insertResult = $insertStmt->execute();
            if ($insertResult) 
            {
                echo "<script>alert('Τα δεδομένα εισάχθηκαν επιτυχώς!')</script>";
                // Create folder for user
                $folderPath = "../uploads/" . $am . "/";
                createFolder($folderPath);
                // Upload files
                uploadFiles($folderPath);
                header('Location: ../index.php');
                exit();
            } 
            else 
            {
                echo "Error inserting data: " . $insertStmt->error;
                echo "<script>alert('Τα δεδομένα δεν εισάχθηκαν επιτυχώς!')</script>";
                header('Location: ../index.php');
                exit();
            }
        }
    }
}

$conn->close();

function createFolder($folderPath) 
{
    if (!file_exists($folderPath)) 
    {
        mkdir($folderPath, 0777, true);
    }
}

function removeFiles($folderPath) 
{
    $files = glob($folderPath . "*");
    foreach ($files as $file) 
    {
        if (is_file($file)) 
        {
            unlink($file);
        }
    }
}

function uploadFiles($folderPath) 
{
    if (isset($_FILES['grades']['tmp_name']) && !empty($_FILES['grades']['tmp_name'])) 
    {
        $gradesFile = $_FILES['grades']['tmp_name'];
        $gradesFileName = $_FILES['grades']['name'];
        $gradesFileSize = $_FILES['grades']['size']; // File size in bytes

        // Use the $gradesFileSize as needed, for example, storing it in the database
        // or performing size validation.

        move_uploaded_file($gradesFile, $folderPath . $gradesFileName);
    }

    if (isset($_FILES['cert']['tmp_name']) && !empty($_FILES['cert']['tmp_name'])) 
    {
        $certFile = $_FILES['cert']['tmp_name'];
        $certFileName = $_FILES['cert']['name'];
        $certFileSize = $_FILES['cert']['size']; // File size in bytes

        // Use the $certFileSize as needed, for example, storing it in the database
        // or performing size validation.

        move_uploaded_file($certFile, $folderPath . $certFileName);
    }

    if (isset($_FILES['moreCert']['tmp_name']) && !empty($_FILES['moreCert']['tmp_name'])) 
    {
        foreach ($_FILES['moreCert']['tmp_name'] as $key => $tmp_name) {
            $moreCertFile = $_FILES['moreCert']['tmp_name'][$key];
            $moreCertFileName = $_FILES['moreCert']['name'][$key];
            $moreCertFileSize = $_FILES['moreCert']['size'][$key]; // File size in bytes

            // Use the $moreCertFileSize as needed, for example, storing it in the database
            // or performing size validation.

            move_uploaded_file($moreCertFile, $folderPath . $moreCertFileName);
        }
    }
}
?>
