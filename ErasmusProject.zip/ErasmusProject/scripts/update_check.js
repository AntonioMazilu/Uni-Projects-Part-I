document.addEventListener('DOMContentLoaded', function() 
{
  document.getElementById('update').addEventListener('submit', function(event) 
  {
    // Prevent form submission
    event.preventDefault(); 
    var name = document.getElementById('όνομα').value;
    var surname = document.getElementById('επίθετο').value;
    var regexName = /\d/;
    var regexSurname = /\d/;

    var student_id = document.getElementById('αριθμός_μητρώου').value;
    var regexDigits = /^\d{13}$/;
    var regexPrefix = /^(2022|2024|2025)/;

    var phone_number = document.getElementById('τηλέφωνο').value;
    var regexPhone = /^\d{10}$/;

    var email = document.getElementById('email').value;
    var regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var regexPasswordLength = /^.{5,}$/;
    var regexPasswordSymbol = /[!#$]/;
    var regexPasswordNumber = /\d/;
    var regexPasswordCapitalLetter = /[A-Z]/;

    var password2 = document.getElementById('password2').value;

    // Perform validation checks
    var isValid = true;
    var message = '';

    if (!name || !surname || !student_id || !phone_number || !email || !username || !password || !password2) 
    {
      isValid = false;
      message = 'Παρακαλώ συμπληρώστε όλα τα πεδία!';
    } 
    else if (regexName.test(name)) 
    {
      isValid = false;
      message = 'Δεν μπορείτε να κάνετε εγγραφή. Το όνομα δεν πρέπει να περιέχει ψηφία';
    } 
    else if (regexSurname.test(surname)) 
    {
      isValid = false;
      message = 'Δεν μπορείτε να κάνετε εγγραφή. Το επίθετο δεν πρέπει να περιέχει ψηφία';
    } 
    else if (!regexDigits.test(student_id)) 
    {
      isValid = false;
      message = 'Ο αριθμός μητρώου πρέπει να αποτελείται από 13 ψηφία';
    } 
    else if (!regexPrefix.test(student_id)) 
    {
      isValid = false;
      message = 'Ο αριθμός μητρώου πρέπει να ξεκινάει με 2022, 2024 ή 2025';
    } 
    else if (!regexPhone.test(phone_number)) 
    {
      isValid = false;
      message = 'Ο αριθμός τηλεφώνου πρέπει να αποτελείται από 10 ψηφία';
    } 
    else if (!regexEmail.test(email)) 
    {
      isValid = false;
      message = 'Παρακαλώ εισάγετε μια έγκυρη διεύθυνση email';
    } 
    else if (!regexPasswordLength.test(password)) 
    {
      isValid = false;
      message = 'Ο κωδικός πρέπει να αποτελείται από τουλάχιστον 5 χαρακτήρες';
    } 
    else if (!regexPasswordSymbol.test(password) || !regexPasswordNumber.test(password) || !regexPasswordCapitalLetter.test(password)) 
    {
      isValid = false;
      message = 'Ο κωδικός πρέπει να περιέχει τουλάχιστον έναν ειδικό χαρακτήρα, έναν αριθμό και ένα κεφαλαίο γράμμα!';
    } 
    else if (password !== password2) 
    {
      isValid = false;
      message = 'Οι κωδικοί δεν ταιριάζουν';
    }

    if (!isValid) 
    {
      alert(message);
      return;
    }

    // Submit the form
    submitForm();
  });



  function submitForm() 
  {
    var form = document.getElementById('update');
    var formData = new FormData(form);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '../php_files/process_update.php', true);
    xhr.onreadystatechange = function() 
    {
      if (xhr.readyState === 4) 
      {
        if (xhr.status === 200) 
        {
          console.log(xhr.responseText);

          try 
          {
            var response = JSON.parse(xhr.responseText);
            if (response.success) 
            {
              alert('H αλλαγή των στοιχείων ήταν επιτυχής');
              // Optionally reset the form after successful submission
              form.reset();

            } 
            else 
            {
              alert('Πρόβλημα κατά την αλλαγή στοιχείων: ' + response.message);
            }
          } 
          catch (error) 
          {
            console.error('Error parsing JSON response:', error);
            alert('Πρόβλημα κατά την λήψη απάντησης από τον σερβερ!');
          }
        } 
        else 
        {
          console.log(xhr.status);
          console.log(xhr.responseText);
          alert('Πρόβλημα υποβολής της φόρμας!');
        }
      }
    };

    xhr.onerror = function() 
    {
      console.log('Request failed.');
      alert('Πρόβλημα υποβολής της φόρμας2!');
    };

    xhr.send(formData);
  }
});
