document.getElementById('applicationForm').addEventListener('submit', function(event) 
{
    event.preventDefault(); // Prevent form submission

    // Retrieve form field values
    var currentYear = document.getElementById('currentyear').value;
    var passPercentage = document.getElementById('ποσοστό_περασμένων_μαθημάτων').value;
    var averageScoreInput = document.getElementById('μέσος_όρος_περασμένων_μαθημάτων');
    var averageScore = parseFloat(averageScoreInput.value);
    //var englishCertification = document.querySelector('input[name="choose1"]:checked').value;
    // console.log("English Certification:", englishCertification);
    var value = document.getElementsByName("choose1");      
    var englishCertification = Array.from(value).find(radio => radio.checked);
    englishCertification = englishCertification.value;

    // Perform validation checks
    var isValid = true;
    var message = "";

    if (!currentYear || !passPercentage || !averageScore || !englishCertification) 
    {
      isValid = false;
      message = "Παρακαλώ συμπληρώστε όλα τα πεδία!";
    }
    else if (currentYear === "1st")
    {
      isValid = false;
      message = "Δεν μπορείτε να προχωρήσετε με την αίτηση. Το έτος σπουδών πρέπει να είναι μεγαλύτερο ή ίσο του 2.";
    } 
    else if (passPercentage < 70) 
    {
      isValid = false;
      message = "Δεν μπορείτε να προχωρήσετε με την αίτηση. Το ποσοστό περασμένων μαθημάτων πρέπει να είναι μεγαλύτερο ή ίσο του 70.";
    }
    else if (passPercentage > 100)
    {
      isValid = false;
      message = "Δεν μπορείτε να προχωρήσετε με την αίτηση. Το ποσοστό περασμένων μαθημάτων πρέπει να είναι το πολύ 100.";
    }
    else if (averageScore < 6.5) 
    {
      isValid = false;
      message = "Δεν μπορείτε να προχωρήσετε με την αίτηση. Ο μέσος όρος περασμένων μαθημάτων πρέπει να είναι μεγαλύτερος ή ίσος του 6.5.";
    }
    else if (averageScore > 10) 
    {
      isValid = false;
      message = "Δεν μπορείτε να προχωρήσετε με την αίτηση. Ο μέσος όρος περασμένων μαθημάτων πρέπει να είναι το πολύ 10.";
    }
    else if (englishCertification === "A1" || englishCertification === "A2" || englishCertification === "B1") 
    {
      isValid = false;
      message = "Δεν μπορείτε να προχωρήσετε με την αίτηση. Το πιστοποιητικό αγγλικών πρέπει να είναι μεγαλύτερο ή ίσο του επιπέδου B2.";
    }
    
    // Display error or eligibility message
    var errorMessage = document.getElementById('errorMessage');
    var eligibilityMessage = document.getElementById('eligibilityMessage');

    if (!isValid) 
    {
      if (!errorMessage) 
      {
        errorMessage = document.createElement('p');
        errorMessage.id = 'errorMessage';
        errorMessage.style.color = 'red';
        document.getElementById('applicationForm').appendChild(errorMessage);
      }
      errorMessage.textContent = message;

      if (eligibilityMessage) 
      {
        eligibilityMessage.remove();
      }
    } 
    else 
    {
      if (!eligibilityMessage) 
      {
        eligibilityMessage = document.createElement('p');
        eligibilityMessage.id = 'eligibilityMessage';
        eligibilityMessage.style.color = 'green';
        document.getElementById('applicationForm').appendChild(eligibilityMessage);
      }
      eligibilityMessage.textContent = "Συγχαρητήρια! Μπορείτε να προχωρήσετε με την αίτηση!";
      if (errorMessage) 
      {
        errorMessage.remove();
      }
    }
});