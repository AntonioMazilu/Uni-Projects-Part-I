document.addEventListener('DOMContentLoaded', function() 
{
  document.getElementById('admin_signup').addEventListener('submit', function(event) 
  {
    // Prevent form submission
    event.preventDefault();
    var name = document.getElementById('όνομα').value;
    var surname = document.getElementById('επίθετο').value;
    var regexName = /\d/;
    var regexSurname = /\d/;

    var student_id = document.getElementById('αριθμός_μητρώου').value;
    var regexDigits = /^\d{13}$/;
    var regexPrefix = /^(2022|2024|2025)/;

    var phone_number = document.getElementById('τηλέφωνο').value;
    var regexPhone = /^\d{10}$/;

    var email = document.getElementById('email').value;
    var regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    var username = document.getElementById('username').value;

    // Perform validation checks
    var isValid = true;
    var message = '';

    if (!name || !surname || !student_id || !phone_number || !email || !username) 
    {
      isValid = false;
      message = 'Παρακαλώ συμπληρώστε όλα τα πεδία!';
    } 
    else if (regexName.test(name)) 
    {
      isValid = false;
      message = 'Δεν μπορείτε να κάνετε εγγραφή. Το όνομα δεν πρέπει να περιέχει ψηφία';
    } 
    else if (regexSurname.test(surname)) 
    {
      isValid = false;
      message = 'Δεν μπορείτε να κάνετε εγγραφή. Το επίθετο δεν πρέπει να περιέχει ψηφία';
    } 
    else if (!regexDigits.test(student_id)) 
    {
      isValid = false;
      message = 'Ο αριθμός μητρώου πρέπει να αποτελείται από 13 ψηφία';
    } 
    else if (!regexPrefix.test(student_id)) 
    {
      isValid = false;
      message = 'Ο αριθμός μητρώου πρέπει να ξεκινάει με 2022, 2024 ή 2025';
    } 
    else if (!regexPhone.test(phone_number)) 
    {
      isValid = false;
      message = 'Ο αριθμός τηλεφώνου πρέπει να αποτελείται από 10 ψηφία';
    } 
    else if (!regexEmail.test(email)) 
    {
      isValid = false;
      message = 'Παρακαλώ εισάγετε μια έγκυρη διεύθυνση email';
    } 

    if (!isValid) 
    {
      alert(message);
      return;
    }


    // Perform AJAX request to check username availability
    checkUsernameAvailability(username)
    .then(function(responseText) 
    {
      console.log('Response:', responseText);
      try 
      {
        var response = JSON.parse(responseText);
        if (response.available) 
        {
          var submitEvent = new Event('submit', 
          {
            bubbles: true,
            cancelable: true
          });
          
          submitForm();

          console.log('Username is available, proceed with form submission');
        } 
        else 
        {
          alert('Το όνομα χρήστη δεν είναι διαθέσιμο.');
        }
      } 
      catch (error) 
      {
        console.error('Error parsing JSON:', error);
        alert('Παρουσιάστηκε σφάλμα κατά την λήψη JSON!');
      }
    })
    .catch(function(error) 
    {
      console.error('Error checking username availability:', error);
      alert('Παρουσιάστηκε σφάλμα κατά τον έλεγχο της διαθεσιμότητας ονόματος χρήστη!');
    });
  });



  function submitForm() 
  {
    var form = document.getElementById('admin_signup');
    var formData = new FormData(form);
  
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '../php_files/process_signup_admin.php', true);
    xhr.onreadystatechange = function() 
    {
      if (xhr.readyState === 4) 
      {
        if (xhr.status === 200) 
        {
          console.log(xhr.responseText);
  
          try 
          {
            var response = JSON.parse(xhr.responseText);
            if (response.success) 
            {
              alert('H εγγραφή ήταν επιτυχής');
              // Optionally reset the form after successful submission
              form.reset(); 

            } 
            else 
            {
              alert('Πρόβλημα κατά την εγγραφή: ' + response.message);
            }
          } 
          catch (error) 
          {
            console.error('Error parsing JSON response:', error);
            alert('Πρόβλημα κατά την λήψη απάντησης από τον σερβερ!');
          }
        } 
        else 
        {
          console.log(xhr.status);
          console.log(xhr.responseText);
          alert('Πρόβλημα υποβολής της φόρμας!');
        }
      }
    };
  
    xhr.onerror = function() 
    {
      console.log('Request failed.');
      alert('Πρόβλημα υποβολής της φόρμας2!');
    };
  
    xhr.send(formData);
  }
  
  
  
  function checkUsernameAvailability(username) 
  {
    return new Promise(function(resolve, reject) 
    {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', '../php_files/check_username.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = function() 
      {
        if (xhr.readyState === 4) 
        {
          if (xhr.status === 200) 
          {
            resolve(xhr.responseText);
          } 
          else 
          {
            reject(xhr.statusText);
          }
        }
      };
      xhr.send('username=' + encodeURIComponent(username));
    });
  }

});