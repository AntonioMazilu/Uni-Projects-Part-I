function loadUniversityOptions(selectId) 
{
  var selectElement = document.getElementById(selectId);
  var xhr = new XMLHttpRequest();

  // Define the request URL
  var url = '../php_files/get_universities_ajax.php';

  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () 
  {
    if (xhr.readyState === 4 && xhr.status === 200) 
    {
      var universities = JSON.parse(xhr.responseText);

      // Clear the select element
      selectElement.innerHTML = '';

      // Add the retrieved options to the select element
      universities.forEach(function (university) 
      {
        var option = document.createElement('option');
        option.value = university.name; // Use the 'value' property from the response
        option.textContent = university.name; // Use the 'name' property from the response
        selectElement.appendChild(option);
      });
    }
  };

  xhr.send();
}

window.onload = function() 
{
  loadUniversityOptions('uni_choice1');
  loadUniversityOptions('uni_choice2');
  loadUniversityOptions('uni_choice3');
};
