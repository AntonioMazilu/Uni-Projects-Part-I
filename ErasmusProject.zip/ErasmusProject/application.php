<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole === 'administrator') 
        {
            header('Location: ./admin.php');
            exit();
        }
    }
    else
    {
      header('Location: ./index.php');
      exit();
    }
?>

<!DOCTYPE html5>
<html lang="el">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Φόρμα Αίτησης σε Erasmus+">
    <title>Φόρμα αίτησης</title>
    <link rel="icon" href="./media/erasmus+.png">
    <link rel="stylesheet" href="./styles/application.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="./scripts/index.js"></script>
    <script src="./scripts/get_universities_ajax.js"></script>
  </head>

  <body>
    
    <?php
      include './php_files/config.php';

      // Query to fetch data from the database
      $query = "SELECT * FROM users WHERE username = ?";
      $stmt = $conn->prepare($query);
      $stmt->bind_param("s", $_SESSION['username']);
      $stmt->execute();
      $result = $stmt->get_result();

      // Fetch the results into an associative array
      $data = $result->fetch_assoc();

      // Close the database connection
      $conn->close();
    ?>

    <div class="container">
      <div class="topnav" id="myTopnav">
        <a href="index.php">Αρχική</a>
          <?php if ($userRole === 'visitor') { ?>
            <a href="login.php">Σύνδεση</a>
            <a href="sign-up.php">Εγγραφή</a>
          <?php } ?>
        <a href="more.php">Πληροφορίες</a>
          <?php if ($userRole === 'regular') { ?>
            <a class="active" href="application.php">Φόρμα αίτησης</a>
          <?php } ?>
        <a href="reqs.php">Προαπαιτούμενες απαιτήσεις</a>
          <?php if ($userRole === 'administrator') { ?>
            <a href="admin.php">Admin</a>
          <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
              <div class="topnav">
                  <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
                  <a href="logout.php">Αποσύνδεση</a>
              </div>
          <?php } ?>
          </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Φόρμα Αίτησης</h1>
          </header>
          <div class="form">
            <form method="POST" action="./php_files/application_insert_data.php" enctype="multipart/form-data">
              <br>
              <label for="όνομα">Όνομα</label><br>
              <input type="text" id="fname" name="ονομα" value="<?php echo $data['fname']; ?>" readonly>
              <br>
              <br>
              <label for="επίθετο">Επίθετο</label><br>
              <input type="text" id="lname" name="επίθετο" value="<?php echo $data['lname']; ?>" readonly><br>
              <br>
              <br>
              <label for="αριθμός_μητρώου">Αριθμός Μητρώου</label><br>
              <input type="text" id="a_m" name="αριθμός_μητρώου" value="<?php echo $data['a_m']; ?>" readonly><br>
              <br>
              <br>
              <label for="ποσοστό_περασμένων_μαθημάτων">Ποσοστό «περασμένων» μαθημάτων</label><br>
              <input type="number" id="passed" name="ποσοστό_περασμένων_μαθημάτων" placeholder="π.χ. 50 για τα μισά μαθήματα" required>
              <br>
              <br>
              <label for="μέσος_όρος_περασμένων_μαθημάτων">Μέσος όρος «περασμένων» μαθημάτων</label><br>
              <input type="number" id="avg_passed" name="μέσος_όρος_περασμένων_μαθημάτων" step="any" placeholder="π.χ. 6 αν ο μ.ο. των περασμένων είναι 6" required>
              <br>
              <br>
              <label for="πιστοποιητικό_αγγλικών">Πιστοποιητικό γνώσης της αγγλικής γλώσσας</label><br>
              <label for="A1-Beginner">A1 </label>
              <input type="radio" id="A1-Beginner" name="gradeeng" value="A1">
              <label for="A2-PreIntermediate">A2 </label>
              <input type="radio" id="A2-PreIntermediate" name="gradeeng" value="A2">
              <label for="B1-Intermediate">B1 </label>
              <input type="radio" id="B1-Intermediate" name="gradeeng" value="B1">
              <label for="B2-Upper-Intermidiate">B2 </label>
              <input type="radio" id="B2-Upper-Intermidiate" name="gradeeng" value="B2">
              <label for="C1-Advanced-Lower">C1 </label>
              <input type="radio" id="C1-Advanced-Lower" name="gradeeng" value="C1">
              <label for="C2-Proficient-Proficiency">C2</label>
              <input type="radio" id="C2-Proficient-Proficiency" name="gradeeng" value="C2">
              <br>
              <br>
              <label>Γνώση Επιπλέον Ξένης Γλώσσας</label><br>
              <label for="yes">Ναι</label>
              <input type="radio" id="yes" value="yes" name="choose1" required>
              <label for="no">Όχι</label>
              <input type="radio" id="no" value="no" name="choose1">
              <br>
              <br>
              <label for="uni_choice1">Επιλογή 1ου Πανεπιστήμιου</label><br>
              <select name="uni_choice1" id="uni_choice1" required>
                <!-- DATA FROM ajax
                  <option value="UOA">Πανεπιστήμιο Άμστερνταμ</option>
                  <option value="UOM">Πανεπιστήμιο Μονάχου</option>
                  <option value="UOB">Πανεπιστήμιο Βαρκελόνης</option>
                  <option value="UOL">Πανεπιστήμιο Λετονίας</option> 
                -->
              </select>
              <br>
              <br>
              <label for="uni_choice2">Επιλογή 2ου Πανεπιστήμιου</label><br>
              <select name="uni_choice2" id="uni_choice2" required>
                <!-- DATA FROM ajax
                  <option value="UOA">Πανεπιστήμιο Άμστερνταμ</option>
                  <option value="UOM">Πανεπιστήμιο Μονάχου</option>
                  <option value="UOB">Πανεπιστήμιο Βαρκελόνης</option>
                  <option value="UOL">Πανεπιστήμιο Λετονίας</option> 
                -->
                </select>
                <br>
                <br>
                <label for="uni_choice3">Επιλογή 3ου Πανεπιστήμιου</label><br>
              <select name="uni_choice3" id="uni_choice3" required>
                <!-- DATA FROM ajax
                  <option value="UOA">Πανεπιστήμιο Άμστερνταμ</option>
                  <option value="UOM">Πανεπιστήμιο Μονάχου</option>
                  <option value="UOB">Πανεπιστήμιο Βαρκελόνης</option>
                  <option value="UOL">Πανεπιστήμιο Λετονίας</option> 
                -->
                </select>
                <br>
                <br>
                <input type="hidden" id="university1Value" name="university1Value">
                <input type="hidden" id="university1Name" name="university1Name">
                <input type="hidden" id="university2Value" name="university2Value">
                <input type="hidden" id="university2Name" name="university2Name">
                <input type="hidden" id="university3Value" name="university3Value">
                <input type="hidden" id="university3Name" name="university3Name">
                
                <label for="grades">Αναλυτική Βαθμολογία</label><br>
                <input type="file" id="grades" name="grades" accept=".pdf,.docx" required> 
                <br>
                <br>
                <label for="cert">Πτυχίο Αγγλικής Γλώσσας</label><br>
                <input type="file" id="cert" name="cert" accept=".pdf,.docx" required>
                <br>
                <br>
                <label for="moreCert">Πτυχίο Άλλων Ξένων Γλωσσών</label><br>
                <input type="file" id="moreCert" name="moreCert[]" multiple accept=".pdf,.docx">
                <br>
                <br>
                <label for="checkbox">Αποδοχή των Όρων</label>
                <input type="checkbox" id="checkbox" name="checkbox" required/>
                <br>
                <br>
                <input type="submit" id="submit" name="submit" value="Υποβολή">
            </form>
          </div>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>