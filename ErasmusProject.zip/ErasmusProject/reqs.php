<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole === 'administrator') 
        {
            header('Location: ./admin.php');
            exit();
        }
    }
?>

<!DOCTYPE html5>
<html lang="el">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Εράσμους Πρόγραμμα">
    <title>Προαπαιτούμενα Δικαιολογητικά</title>
    <link rel="icon" href="./media/erasmus+.png">
    <link rel="stylesheet" href="./styles/reqs.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="./scripts/index.js"></script>
  </head>

  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <a href="index.php">Αρχική</a>
        <?php if ($userRole === 'visitor') { ?>
          <a href="login.php">Σύνδεση</a>
          <a href="sign-up.php">Εγγραφή</a>
        <?php } ?>
        <a href="more.php">Πληροφορίες</a>
        <?php if ($userRole === 'regular') { ?>
          <a href="application.php">Φόρμα αίτησης</a>
        <?php } ?>
        <a class="active" href="reqs.php">Προαπαιτούμενες απαιτήσεις</a>
        <?php if ($userRole === 'administrator') { ?>
          <a href="admin.php">Admin</a>
        <?php } ?>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
              <div class="topnav">
                  <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
                    <a href="logout.php">Αποσύνδεση</a>
              </div>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Προαπαιτούμενες Απαιτήσεις</h1>
          </header>
          <div class="paragraph">
            <br>
            <table>
                <tr>
                  <th>Τρέχον έτος σπουδών:</th>
                  <td>Aπαίτηση: Πρέπει μεγαλύτερο ή ίσο του 2ου έτους</td>
                </tr>
                <tr>
                  <th>Ποσοστό «περασμένων» μαθημάτων έως το προηγούμενο έτος σπουδών: </th>
                  <td>Aπαίτηση: Πρέπει μεγαλύτερο ή ίσο του 70% του συνόλου των μαθημάτων.</td>
                </tr>
                <tr>
                  <th>Μέσος όρος των «περασμένων» μαθημάτων έως το προηγούμενο έτος σπουδών:</th>
                  <td>Aπαίτηση: Πρέπει μεγαλύτερο ή ίσο του 6.50.</td>
                </tr>
                <tr>
                  <th>Πιστοποιητικό γνώσης της αγγλικής γλώσσας:</th>
                  <td>Aπαίτηση: Πρέπει το λιγότερο «καλή γνώση της αγγλικής γλώσσας», που αντιστοιχεί σε επίπεδο B2 ή ανώτερο.</td>
                </tr>
              </table>
          <div>
        <div class="images">
          <div class="image-row">
            <img src="./media/uopeu.png" alt="UopEUerasmus">
          </div>
        </div>
        <header>
          <h1>Γρήγορος 'Ελεγχος</h1>
        </header>
        <div class="form">
          <form id="applicationForm">
            <br>
            <label for="currentyear">Έτος σπουδών</label><br>
            <select name="currentyear" id="currentyear" required>
              <option value="" selected disabled>Διάλεξε έτος σπουδών</option>
              <option value="1st">1ο Έτος Σπουδών</option>
              <option value="2nd">2ο Έτος Σπουδών</option>
              <option value="3rd">3ο Έτος Σπουδών</option>
              <option value="4th">4ο Έτος Σπουδών</option>
            </select>
            <br>
            <label for="ποσοστό_περασμένων_μαθημάτων">Ποσοστό «περασμένων» μαθημάτων</label><br>
            <input type="number" id="ποσοστό_περασμένων_μαθημάτων" name="ποσοστό_περασμένων_μαθημάτων" placeholder="π.χ. 50 για τα μισά μαθήματα" required>
            <br>
            <br>
            <label for="μέσος_όρος_περασμένων_μαθημάτων">Μέσος όρος «περασμένων» μαθημάτων</label><br>
            <input type="number" id="μέσος_όρος_περασμένων_μαθημάτων" name="μέσος_όρος_περασμένων_μαθημάτων" step="any" placeholder="π.χ. 6.5 αν ο μ.ο. των περασμένων είναι 6.5" required>
            <br>
            <br>
            <label for="πιστοποιητικό_αγγλικών">Πιστοποιητικό γνώσης της αγγλικής γλώσσας</label><br>
            <label for="A1-Beginner">A1 </label>
            <input type="radio" id="A1-Beginner" name="choose1" value="A1" required>
            <label for="A2-PreIntermediate">A2 </label>
            <input type="radio" id="A2-PreIntermediate" name="choose1" value="A2">
            <label for="B1-Intermediate">B1 </label>
            <input type="radio" id="B1-Intermediate" name="choose1" value="B1">
            <label for="B2-Upper-Intermidiate">B2 </label>
            <input type="radio" id="B2-Upper-Intermidiate" name="choose1" value="B2">
            <label for="C1-Advanced-Lower">C1 </label>
            <input type="radio" id="C1-Advanced-Lower" name="choose1" value="C1">
            <label for="C2-Proficient-Proficiency">C2</label>
            <input type="radio" id="C2-Proficient-Proficiency" name="choose1" value="C2">
            <br>
            <br>
            <input type="submit" id="submit" name="submit" value="Υποβολή">
          </form>
        </div>
        <script src="./scripts/fast_check.js"></script>
    </main>
    <footer class="footer">
      <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
    </footer>
  </div>
</body>
</html>
