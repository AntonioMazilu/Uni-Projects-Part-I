<?php
    // Assuming you have started the session
    session_start();

    // Initialize $userRole with a default value
    $userRole = 'visitor';

    // Check if the user is logged in and their role
    if (isset($_SESSION['role'])) 
    {
        $userRole = $_SESSION['role'];
        if ($userRole === 'administrator') 
        {
            header('Location: ./admin.php');
            exit();
        }
        if ($userRole === 'regular') 
        {
            header('Location: ./index.php');
            exit();
        }
    }
?>

<!DOCTYPE html5>
<html lang="el">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Φόρμα Αίτησης σε Erasmus+">
    <title>Σύνδεση</title>
    <link rel="icon" href="./media/erasmus+.png">
    <link rel="stylesheet" href="./styles/login.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <script src="./scripts/index.js"></script>
  </head>

  <body>
    <div class="container">
      <div class="topnav" id="myTopnav">
        <a href="index.php">Αρχική</a>
        <a class="active" href="login.php">Σύνδεση</a>
        <?php if ($userRole === 'visitor') { ?>
          <a href="sign-up.php">Εγγραφή</a>
        <?php } ?>
        <a href="more.php">Πληροφορίες</a>
        <?php if ($userRole === 'regular') { ?>
          <a href="application.php">Φόρμα αίτησης</a>
        <?php } ?>
        <?php if ($userRole === 'administrator') { ?>
          <a href="admin.php">Admin</a>
        <?php } ?>
        <a href="reqs.php">Προαπαιτούμενες απαιτήσεις</a>
        <div class="user-section" style="float:right">
          <?php if (isset($_SESSION['username'])) { ?>
            <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
            <a href="logout.php">Αποσύνδεση</a>
          <?php } ?>
        </div>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
    </div>
      <div class="wrapper">
        <main>
          <header>
            <h1>Σύνδεση</h1>
          </header>
          <div class="form">
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
              <br>
              <br>
              <label for="όνομα">Όνομα Χρήστη</label><br>
              <input type="text" id="όνομα" name="όνομα" placeholder="Όνομα Χρήστη" required>
              <br>
              <br>
              <label for="password">Κωδικός Πρόσβασης</label><br>
              <input type="password" id="password" name="password" placeholder="Κωδικός Πρόσβασης" required>
              <br>
              <br>
              <input type="submit" id="submit" name="submit" value="Σύνδεση">           
            </form>
            <?php
              if (isset($_GET['error']) && $_GET['error'] == 1) 
              {
                  echo '<p>Λάθος κωδικός πρόσβασης!</p>';
              }
            ?>
            <?php
              if (isset($_GET['error']) && $_GET['error'] == 2) 
              {
                  echo '<p>Δεν βρέθηκε χρήστης!</p>';
              }
            ?>
          </div>
          <?php
            include './php_files/config.php';

            if (isset($_POST["submit"])) 
            {
              // Get user input from the login form
              $username = $_POST['όνομα'];

              if ($username) 
              {
                // User has entered both username and password
                // Prepare and execute a query to check if the user exists and retrieve their associated type and password
                $selectQuery = "SELECT users.*, type.user_type FROM users INNER JOIN type ON users.user_type_id = type.user_type_id WHERE username = ?";
                $stmt = $conn->prepare($selectQuery);
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();

                if ($user) 
                {
                  // User exists, retrieve their type and hashed password
                  $userType = $user['user_type'];
                  $storedHashedPassword = $user['password'];

                  // Verify the password
                  $password = $_POST['password'];
                  if (password_verify($password, $storedHashedPassword)) 
                  {
                    // Password is correct

                    // Store the role value in the session
                    session_start();
                    $_SESSION['role'] = $userType;
                    $_SESSION['username'] = $username;

                    // Redirect to the appropriate page
                    if ($userType === 'regular') 
                    {
                        header('Location: ./index.php'); // Redirect to regular user page
                        exit();
                    } 
                    else if ($userType === 'administrator') 
                    {
                        header('Location: ./admin.php'); // Redirect to admin page
                        exit();
                    }
                  } 
                  else 
                  {
                      // Password is incorrect
                      // Handle accordingly (e.g., display error message, redirect to login page)
                      header('Location: ./login.php?error=1');
                      exit();
                  }
                } 
                else 
                {
                  // User does not exist or invalid credentials
                  // Handle accordingly (e.g., display error message, redirect to login page)
                  header('Location: ./login.php?error=2');
                  exit();
                }
              }
            }

            $conn->close();
          ?>
        </main>
        <footer class="footer">
          <p>&copy; 2023 Erasmus+ UoP. All rights reserved.</p>
        </footer>
      </div>
    </div>
  </body>
</html>
