-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2023 at 09:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `a_m` text NOT NULL,
  `passed` int(50) NOT NULL,
  `avg_passed` double NOT NULL,
  `cert` text NOT NULL,
  `extra_know` text NOT NULL,
  `1option` text NOT NULL,
  `2option` text NOT NULL,
  `3option` text NOT NULL,
  `detail_cert` text NOT NULL,
  `diploma_eng` text NOT NULL,
  `diploma_other` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `fname`, `lname`, `a_m`, `passed`, `avg_passed`, `cert`, `extra_know`, `1option`, `2option`, `3option`, `detail_cert`, `diploma_eng`, `diploma_other`) VALUES
(1, 'Konstantinos', 'Ntouros', '2022202000153', 65, 7, 'B2', 'yes', 'University of California, Berkeley', 'University of Oxford', 'University of Toronto', 'C:\\xampp\\tmp\\php970.tmp', 'C:\\xampp\\tmp\\php971.tmp', 'Array'),
(2, 'Ion Antonio', 'Mazilou', '2022202000131', 89, 7.5, 'C1', 'yes', 'Stanford University', 'Columbia University', 'Yale University', 'C:\\xampp\\tmp\\phpB8DD.tmp', 'C:\\xampp\\tmp\\phpB8DE.tmp', 'Array');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `user_type_id` int(5) NOT NULL,
  `user_type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `user_type_id`, `user_type`) VALUES
(1, 2, 'administrator'),
(2, 1, 'regular'),
(3, 1, 'regular');

-- --------------------------------------------------------

--
-- Table structure for table `uni`
--

CREATE TABLE `uni` (
  `id` int(11) NOT NULL,
  `uni_id` int(5) NOT NULL,
  `uni_name` text NOT NULL,
  `country` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uni`
--

INSERT INTO `uni` (`id`, `uni_id`, `uni_name`, `country`) VALUES
(1, 0, 'Harvard University', 'United States'),
(2, 0, 'Oxford University', 'United Kingdom'),
(3, 0, 'University of Manchester', 'United Kingdom'),
(4, 0, 'Stanford University', 'United States'),
(5, 0, 'Massachusetts Institute of Technology (MIT)', 'United States'),
(6, 0, 'California Institute of Technology (Caltech)', 'United States'),
(7, 0, 'University of Cambridge', 'United Kingdom'),
(8, 0, 'University of Oxford', 'United Kingdom'),
(9, 0, 'University of Chicago', 'United States'),
(10, 0, 'Imperial College London', 'United Kingdom'),
(11, 0, 'Princeton University', 'United States'),
(12, 0, 'University of California, Berkeley', 'United States'),
(13, 0, 'Yale University', 'United States'),
(14, 0, 'Columbia University', 'United States'),
(15, 0, 'University of Toronto', 'Canada'),
(16, 0, 'University of Melbourne', 'Australia'),
(17, 0, 'University of Tokyo', 'Japan'),
(18, 0, 'Swiss Federal Institute of Technology Zurich (ETH Zurich)', 'Switzerland'),
(19, 0, 'National University of Singapore (NUS)', 'Singapore'),
(20, 0, 'Sorbonne University', 'France');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `a_m` text NOT NULL,
  `tel` text NOT NULL,
  `email` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `user_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `a_m`, `tel`, `email`, `username`, `password`, `user_type_id`) VALUES
(1, 'Nikolaos', 'Tselikas', '2022999999999', '6999999999', 'ntsel@uop.gr', 'Ntsel', '$2y$10$9U0109JwYgKFV3mx1b5cYOZbkgAs6E5ppvP98NZaM9vsGfgswHnZi', 2),
(2, 'Konstantinos', 'Ntouros', '2022202000153', '6998042204', 'dit20153@go.uop.gr', 'Kostas', '$2y$10$RyRy6sZ26RmziztMy.ObluCy1/DwyCqXTmGmwaRG9S/4aiI58yTyi', 1),
(3, 'Ion Antonio', 'Mazilou', '2022202000131', '6993863283', 'dit20131@go.uop.gr', 'Toni', '$2y$10$NZ6zSdfl0HFbCtqOp28uiOxa5Rh9i35FqDaUC0igsvAnw6XyETLOu', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uni`
--
ALTER TABLE `uni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `uni`
--
ALTER TABLE `uni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
