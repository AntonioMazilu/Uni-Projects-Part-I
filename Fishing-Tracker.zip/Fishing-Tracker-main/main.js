const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs').promises;

let mainWindow;

// Function to get the images directory path
const getImagesDir = () => path.join(app.getPath('userData'), 'images');

// Ensure the images directory exists
const ensureImagesDir = async () => {
    const imagesDir = getImagesDir();
    try {
        await fs.mkdir(imagesDir, { recursive: true });
        console.log('Images directory is ready:', imagesDir);
    } catch (error) {
        console.error('Error creating images directory:', error);
    }
};

// Create the main application window
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1920,
        height: 1080,
        minHeight: 600,
        minWidth: 800,
        icon: path.join(__dirname, 'assets/fishing.png'),
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
        }
    });

    mainWindow.loadFile('index.html');

    // Optional: Open DevTools
    // mainWindow.webContents.openDevTools();
}

// App lifecycle events
app.whenReady().then(async () => {
    await ensureImagesDir();
    createWindow();

    app.on('activate', function () {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') app.quit();
});

ipcMain.handle('save-image', async (event, filePath, productId) => {

    const imagesDir = getImagesDir();
    const fileName = path.basename(filePath);
    const uniqueName = `${productId}-${fileName}`;
    const destPath = path.join(imagesDir, uniqueName);

    try {
        await fs.copyFile(filePath, destPath);
        console.log(`Image copied to: ${destPath}`);
        return destPath;
    } catch (error) {
        console.error('Error copying image:', error);
        return null;
    }
});

// IPC handler to select and copy an image
ipcMain.handle('open-file-dialog', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Product Image',
        properties: ['openFile'],
        filters: [
            { name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'] }
        ]
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const selectedPath = result.filePaths[0];
    const imagesDir = getImagesDir();
    const fileName = path.basename(selectedPath);
    const uniqueName = `${Date.now()}-${fileName}`;
    const destPath = path.join(imagesDir, uniqueName);

    try {
        await fs.copyFile(selectedPath, destPath);
        console.log(`Image copied to: ${destPath}`);
        return destPath;
    } catch (error) {
        console.error('Error copying image:', error);
        return null;
    }
});

// IPC handler to delete an image
ipcMain.handle('delete-image', async (event, imagePath) => {
    try {
        await fs.unlink(imagePath);
        console.log(`Image deleted: ${imagePath}`);
        return true;
    } catch (error) {
        console.error('Error deleting image:', error);
        return false;
    }
});