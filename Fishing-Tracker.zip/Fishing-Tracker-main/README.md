# Fishing-Tracker

# Install
- Go to the root folder and type npm install to install the required dependencies.

# Start the App
- Type npm start to start the App in Development Mode.
