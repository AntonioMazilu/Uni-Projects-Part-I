const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    openFileDialog: () => ipcRenderer.invoke('open-file-dialog'),
    saveImage: (filePath, productId) => ipcRenderer.invoke('save-image', filePath, productId)
});