let items = [];

// Load items from localStorage when the app starts
window.onload = function() {
    const storedItems = localStorage.getItem('fishingItems');
    if (storedItems) {
        items = JSON.parse(storedItems);
        renderItems();
        updateTotalPrice();
    }
};

// Save items to localStorage
function saveItems() {
    localStorage.setItem('fishingItems', JSON.stringify(items));
}

// Default placeholder image path
const defaultImagePath = 'assets/placeholder.png';

// Choose image button click handler
document.getElementById('choose-image').addEventListener('click', async () => {
    try {
        const filePath = await window.electronAPI.openFileDialog();
        console.log('File Path:', filePath);
        if (filePath) {
            const productId = Date.now().toString(); // Generate a unique ID for the product
            const savedImagePath = await window.electronAPI.saveImage(filePath, productId);
            console.log('Saved Image Path:', savedImagePath);
            const imageElement = document.getElementById('product-image');
            imageElement.src = `file://${savedImagePath}`;
            imageElement.style.display = 'block';
        }
    } catch (error) {
        console.error('Error choosing image:', error);
    }
});


// Add event listener to save new items
document.getElementById('save-item').addEventListener('click', () => {
    const name = document.getElementById('product-name').value;
    const description = document.getElementById('product-description').value;
    const quantity = parseInt(document.getElementById('product-quantity').value, 10);
    const price = parseFloat(document.getElementById('product-price').value);
    const size = document.getElementById('product-size').value;
    const imageSrc = document.getElementById('product-image').src || defaultImagePath;
    const link = document.getElementById('product-link').value;

    if (!name || isNaN(quantity) || isNaN(price)) {
        showToast('Please fill in all fields.', 'bg-danger');
        return;
    }

    const newItem = {
        id: Date.now().toString(),
        name,
        description,
        quantity,
        price,
        size,
        imageSrc,
        link
    };

    items.push(newItem);
    saveItems();
    renderItems();
    updateTotalPrice();

    showToast('Item added successfully.', 'bg-success');

    // Close modal
    const addModal = new bootstrap.Modal(document.getElementById('addModal'));
    addModal.hide();

    // Reset the form
    document.getElementById('product-image').style.display = 'none';
    document.getElementById('product-name').value = '';
    document.getElementById('product-description').value = '';
    document.getElementById('product-quantity').value = '';
    document.getElementById('product-price').value = '';
    document.getElementById('product-size').value = '';
    document.getElementById('product-link').value = '';
});

function addItemCard(item) {
    const itemList = document.getElementById('item-list');
    const card = document.createElement('div');
    card.classList.add('col-md-4');

    card.innerHTML = `
        <div class="card shadow-sm h-100">
            <img src="${item.imageSrc}" class="card-img-top" alt="${item.name}" onerror="this.src='${defaultImagePath}'" style="height: 200px; object-fit: cover;">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">${item.name}</h5>
                <p class="card-text text-truncate">${item.description}</p>
                <p class="card-text"><strong>Quantity:</strong> ${item.quantity}</p>
                <p class="card-text"><strong>Price:</strong> $${item.price.toFixed(2)}</p>
                <p class="card-text"><strong>Size:</strong> ${item.size}</p>
                <a href="${item.link}" target="_blank" class="btn btn-info mb-2">Source Link</a>
                <button class="btn btn-secondary mb-2 edit-item mt-auto" data-id="${item.id}" data-bs-toggle="modal" data-bs-target="#editModal">
                    <i class="bi bi-pencil"></i> Edit Details
                </button>
                <button class="btn btn-danger delete-item" data-id="${item.id}">
                    <i class="bi bi-trash"></i> Remove
                </button>
            </div>
        </div>
    `;

    itemList.appendChild(card);

    // Add event listener for the edit button
    card.querySelector('.edit-item').addEventListener('click', (e) => {
        const id = e.target.closest('button').dataset.id;
        viewItemDetails(id);
    });

    // Add event listener for the delete button
    card.querySelector('.delete-item').addEventListener('click', (e) => {
        const id = e.target.closest('button').dataset.id;
        deleteItem(id);
    });
}

function viewItemDetails(id) {
    const item = items.find(item => item.id === id);
    if (item) {
        document.getElementById('edit-product-image').src = item.imageSrc;
        document.getElementById('edit-product-name').value = item.name;
        document.getElementById('edit-product-description').value = item.description;
        document.getElementById('edit-product-quantity').value = item.quantity;
        document.getElementById('edit-product-price').value = item.price.toFixed(2);
        document.getElementById('edit-product-size').value = item.size;
        document.getElementById('edit-product-link').value = item.link;

        // Set edit item id
        document.getElementById('save-edits').dataset.id = item.id;
    }
}

document.getElementById('save-edits').addEventListener('click', () => {
    const id = document.getElementById('save-edits').dataset.id;
    const name = document.getElementById('edit-product-name').value;
    const description = document.getElementById('edit-product-description').value;
    const quantity = parseInt(document.getElementById('edit-product-quantity').value, 10);
    const price = parseFloat(document.getElementById('edit-product-price').value);
    const size = document.getElementById('edit-product-size').value;
    const imageSrc = document.getElementById('edit-product-image').src || defaultImagePath;
    const link = document.getElementById('edit-product-link').value;

    if (!name || isNaN(quantity) || isNaN(price)) {
        showToast('Please fill in all fields.', 'bg-danger');
        return;
    }

    const itemIndex = items.findIndex(item => item.id === id);
    if (itemIndex > -1) {
        items[itemIndex] = {
            id,
            name,
            description,
            quantity,
            price,
            size,
            imageSrc,
            link
        };
        saveItems();
        updateTotalPrice();
        renderItems();
        showToast('Item updated successfully.', 'bg-success');

        const editModal = new bootstrap.Modal(document.getElementById('editModal'));
        editModal.hide();
    }
});

function deleteItem(id) {
    items = items.filter(i => i.id !== id);
    updateTotalPrice();
    saveItems();
    renderItems();
    showToast('Item removed successfully.', 'bg-danger');
}

function updateTotalPrice() {
    const totalPrice = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.getElementById('total-price').innerText = totalPrice.toFixed(2);
}

function renderItems() {
    const itemList = document.getElementById('item-list');
    itemList.innerHTML = '';
    items.forEach(addItemCard);
}

function showToast(message, bgClass) {
    const toastHTML = `
        <div class="toast align-items-center text-white ${bgClass} border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;
    const toastContainer = document.getElementById('toast-container');
    toastContainer.innerHTML = toastHTML;
    const toast = new bootstrap.Toast(toastContainer.querySelector('.toast'));
    toast.show();
}