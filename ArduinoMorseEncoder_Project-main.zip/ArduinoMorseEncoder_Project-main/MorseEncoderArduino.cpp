// #include <Wire.h> 
// #include <Arduino.h>
// #include <LiquidCrystal_I2C.h>

// LiquidCrystal_I2C lcd(0x3F, 16, 2);

// String code = "";
// int stringline = 0;
// int len = 0;
// char ch;
// char new_char;
// const int but = 2;
// const int led = 13;
// unsigned long pres_len = 0, rel_time, pres_time = 0, old_time_len = 0, old_pres = 0, space = 0;
// int state = 0;
// int unit_delay = 250;
// int min_delay = 10;


// char MakeString()
// {
//   if (pres_len < (unit_delay*3) && pres_len > 50)
//   {
//     return '.';                        //if button press less than 0.6sec, it is a dot
//   }
//   else if (pres_len > (unit_delay*3))
//   {
//     return '-';                        //if button press more than 0.6sec, it is a dash
//   }
// }
// void Morse_decod()
// {
//   static String morse[] = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....",
//   "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-",
//   ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..", "!"
//   };

//   int i = 0;
//   while (morse[i] != "!")
//   {

//     if (morse[i] == code)
//     {
//       lcd.print(char('A' + i));
//       //lcd.print(" ");

//       if (stringline == 16)
//       {
//         lcd.setCursor(0,1);
//       }

//       stringline++;

//       break;
//     }

//     i++;
//   }

//   if (morse[i] == "!")
//   {
//     lcd.begin();
//   }

//   code = "";
// }


// void setup() 
// {
//   Serial.begin(9600);
//   pinMode(but, INPUT_PULLUP);
//   pinMode(led, OUTPUT);

//   // initialize the LCD
//   lcd.begin();

//   // Turn on the blacklight and print a message.
//   lcd.backlight();

  
// }


// void loop()
// {

  
//   label:
//   while (digitalRead(but) == HIGH) {}

//   old_pres = rel_time;
//   pres_time = millis();
//   digitalWrite(led, HIGH);

//   while (digitalRead(but) == LOW) {}

//   rel_time = millis();
//   digitalWrite(led, LOW);
//   pres_len = rel_time - pres_time;
//   space = pres_time - old_pres;

//   if (pres_len > min_delay)
//   {
//     code += MakeString();
//   }

//   while ((millis() - rel_time) < (unit_delay * 3))
//   {
//     if (digitalRead(but) == LOW)
//     {
//       goto label;
//     }
//   }

//   Morse_decod();
// }