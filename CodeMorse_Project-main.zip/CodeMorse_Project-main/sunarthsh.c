#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"

int encode(char word,char codemorse[],int j)//metatroph apo xarakthra se morse
{

    if(word == 'A')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        j = j + 2;
    }
    else if(word == 'B')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == 'C')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == 'D')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        j = j + 3;
    }
    else if(word == 'E')
    {
        codemorse[j] = '.';
        j = j + 1;
    }
    else if(word == 'F')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == 'G')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        j = j + 3;
    }
    else if(word == 'H')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == 'I')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        j = j + 2;
    }
    else if(word == 'J')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '_';
        j = j + 4;
    }
    else if(word == 'K')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '_';
        j = j + 3;
    }
    else if(word == 'L')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == 'M')
    {
        codemorse[j] = '_';
        codemorse[j+1] = '_';
        j = j + 2;
    }
    else if(word == 'N')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        j = j + 2;
    }
    else if(word == 'O')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        j = j + 3;
    }
    else if(word == 'P')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == 'Q')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '_';
        j = j + 4;
    }
    else if(word == 'R')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        j = j + 3;
    }
    else if(word == 'S')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        j = j + 3;
    }
    else if(word == 'T')
    {
        codemorse[j] = '_';
        j = j + 1;
    }
    else if(word == 'U')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '_';
        j = j + 3;
    }
    else if(word == 'V')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '_';
        j = j + 4;
    }
    else if(word == 'W')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        j = j + 3;
    }
    else if(word == 'X')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '_';
        j = j + 4;
    }
    else if(word == 'Y')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '_';
        j = j + 4;
    }
    else if(word == 'Z')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        j = j + 4;
    }
    else if(word == '1')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '_';
        codemorse[j + 4] = '_';
        j = j + 5;
    }
    else if(word == '2')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '_';
        codemorse[j + 4] = '_';
        j = j + 5;
    }
    else if(word == '3')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '_';
        codemorse[j + 4] = '_';
        j = j + 5;
    }
    else if(word == '4')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '_';
        j = j + 5;
    }
    else if(word == '5')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '.';
        j = j + 5;
    }
    else if(word == '6')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '.';
        j = j + 5;
    }
    else if(word == '7')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '.';
        j = j + 5;
    }
    else if(word == '8')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '.';
        j = j + 5;
    }
    else if(word == '9')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '_';
        codemorse[j + 4] = '.';
        j = j + 5;
    }
    else if(word == '0')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '_';
        codemorse[j + 3] = '_';
        codemorse[j + 4] = '_';
        codemorse[j + 5] = '_';
        j = j + 6;
    }
    else if(word == '.')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '_';
        codemorse[j + 4] = '.';
        codemorse[j + 5] = '_';
        j = j + 6; 
    }
    else if(word == ',')
    {
        codemorse[j] = '_';
        codemorse[j + 1] = '_';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '_';
        codemorse[j + 5] = '_';
        j = j + 6;
    }
    else if(word == ' ')
    {
        codemorse[j] = '.';
        codemorse[j + 1] = '.';
        codemorse[j + 2] = '.';
        codemorse[j + 3] = '.';
        codemorse[j + 4] = '.';
        codemorse[j + 5] = '.';
        j = j + 6;
    }
    else if(word == '@')
    {
        codemorse[j] = '@';
        j = j + 1;
    }

    return j;
}
