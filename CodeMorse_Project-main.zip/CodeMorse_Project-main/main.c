//ΠΑΥΛΟΣ ΣΥΓΡΙΜΗΣ AM:2022202000202
//ΙΟΝ ΑΝΤΟΝΙΟ ΜΑΖΙΛΟΥ AM:2022202000131
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"
#define MAX_SIZE 100

struct Nodas {
    char data;
    int aristera;
    int dejia;
};

struct Nodas tree[MAX_SIZE];
int size = 0;

int newNode(char data) {
    tree[size].data = data;
    tree[size].aristera = -1;
    tree[size].dejia = -1;
    return size++;
}

void build(char *code, int index, int *current) {
    if (code[index] == '\0') {
        return;
    }
    int nodas = newNode(code[index]);
    if (code[index] == '.') {
        tree[*current].aristera = nodas;
        printf("%c", tree[index].data);
        build(code, index+1, &tree[nodas].aristera);
    } else {
        tree[*current].dejia = nodas;
        printf("%c", tree[index].data);
        build(code, index+1, &tree[nodas].dejia);
    }
}

int main(void)
{
    int i = 0,j = 0,k = 0;
    int array[18];//gia to diabasma sto asci arxeio
    char word[18];//apo ariumous se xarakthres
    char codemorse[39];//apo xarakthres se code morse 0="....",".---"
    char output[39];
    char tree[30];
    char temp;


    FILE *fpfile1, *fpfile2,*fpfile3;
    
    fpfile1 = fopen("ascitext.txt","r+");//anoigei to arxeio ascitext.Edo periexein to mnm se aci morfh

    if(fpfile1 == NULL)//elegxos
    {
        printf("File could not be opened\n");
        exit(1);
    }
    
    fpfile2 = fopen("output.txt","w+");//anoigei to arxeio output edo exei to mnm se code morse

    if(fpfile2 == NULL)//elegxos
    {
        printf("File could not be opened\n");
        exit(1);
    }

    while (!feof(fpfile1))//gia na diabazei apo to arxeio asci kai tous kanei xarakthres
    {
        fscanf(fpfile1,"%d",&array[i]);
        word[i] = (char) array[i];
        i++;
    }

    printf("To arxiko mhnyma\n");//allajei grammh

    //debugging
    for(i = 0;i < 18;i++)//gia na diabazei apo to arxeio asci kai tous kanei xarakthres
    {
        printf("%c",word[i]);
    }

    printf("\n");//allajei grammh

    for(j = 0;j < 18;j++)//gia na kodikopoiei se kodika morse kai na to apouhkeuei sto pinaka codemorse
    {
        temp = word[j];
        k = encode(temp,codemorse,k);//kaleitai h synarthsh gia kodikopoihsh
    }

    for(i = 0;i < 38;i++)//printarei sto output to code morse tou mnm
    {
        fprintf(fpfile2,"%c",codemorse[i]);

    }


    fclose(fpfile2);//kleinei to arxeio pou exei to mnm se code morse

    fpfile3 = fopen("output.txt","r");//diabazei to arxeio output edo exei to mnm se code morse

    printf("To mhnyma se code morse\n");//allajei grammh

    char ch;
    i = 0;

    while ((ch = fgetc(fpfile3)) != EOF)//pairnei apo to arxeio to code morse
    {
        output[i] = ch;
        printf("%c", output[i]);
        i++;
    }
    printf("\n");
    printf("teleutaio i = %d\n",i);
    printf("teleutaio = %c\n",output[i]);
    printf("i - 1 = %c\n",output[i-1]);
    output[i] = '\n';

    printf("\n");//allajei grammh
    j = 1;
    i = 0;
    tree[0] = ' ';//h riza einai kenh

    while(1)//ftiaxnei to dentro kai analoga ton xarakthra kineitai aristera h dejia
    {
        if(output[i] == '.')
        {
            tree[j] = '.';
            j++;
        }
        else if(output[i] == '_')
        {
            tree[j] = '_';
            j++;
        }
        // else if(output[i] == '+')
        // {
        //     tree[j] = '+';
        //     j++;
        // }
        // else if(output[i] == '@')
        // {
        //     tree[j] = '@';
        //     j++;
        // }
        else if(output[i] == '\0')
        {
            tree[j] = '\0';
            //printf("\nmphke mesa kai efage break brhke \\0 \n");
            break;
        }
        i++;
    }
    printf("\n");
    // printf("bghke eksw epidh brhke \\0 kai stamathse thn while\n");
    // printf("To code morse sto dentro\n");//allajei grammh

    for(i = 0; tree[i] != '\0';i++)
    {
        printf("mphke mesa na printarei thn tree: ");
        printf("%c\n", tree[i]);
    }

    char str[100];
    strcpy(str, tree);
    printf("To alfarithmitiko einai: %s\n", str);

    int root = newNode(str[0]);
    build(str, 1, &root);
    printf("\n");
    printf("Tree created and printed\n");

    printf("\n");
    fclose(fpfile1);//kleinei to asci arxeio
    fclose(fpfile3);//kleinei to arxeio pou exei to mnm se code morse

    return 0;
}