//Functions
int encode(char word,char codemorse[],int j);//dhlvsh synarthsh