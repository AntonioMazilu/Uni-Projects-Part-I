#include <stdio.h>


int yylex(FILE *fpointer, union semantic_info *sem);


union semantic_info
{
 char *s;
 int i;
} SEMANTIC_INFO;

int yylex()
{
int nextcharacter;
char lexeme[100];
while ( (nextcharacter = fgetc(fp)) != EOF )
{
    //DFA;
}
AssempleSemanticInfo();
}


void main()
{
    int tokentype;
    while ( (tokentype = yylex(fp,sem)) != 0 )
    {
        if ( tokentype == 1 )
        {
        //Action1;
        }
        else if ( tokentype == 2)
        {
        //Action2;
        }
    }

switch (state)
{
    case 0: // state0
    if ( nextcharacter == isalpha )
    {
        //Actionuuu
    }
    else if ( nextcharacter == isnumber )
    {
        //Action
    }
    else 
    {
        //Actions
    }

    case 1: // state1
}